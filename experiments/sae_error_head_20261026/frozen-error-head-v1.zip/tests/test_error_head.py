import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np

from routing.error_head.metrics import ErrorHistogram, interior_mask
from routing.error_head.data import load_record, split_check
from routing.frozen.common import cache_path


def synthetic_cache(root, names):
    root.mkdir()
    meta = {"schema": 1, "complete": True, "images": names, "dataset": "synthetic",
            "split": "val", "size": [8, 8], "layers": ["F2", "F3"],
            "b0": "frozen-b0", "b2": "frozen-b2", "b0_revision": "a", "b2_revision": "b",
            "tile": 4, "margin": 1, "b2_input": "image", "precision": "fp32"}
    (root / "manifest.json").write_text(json.dumps(meta))
    for i, name in enumerate(names):
        gt = np.zeros((8, 8), np.uint8)
        gt[0, 0] = 255
        pred = np.zeros_like(gt)
        pred[2:6, 2:6] = 1
        b2 = np.zeros_like(gt)
        b2[2, 2] = 1
        rng = np.random.default_rng(i + 42)
        np.savez_compressed(cache_path(root, name), b0=pred, b2=b2, gt=gt, valid=gt != 255,
                            entropy=rng.uniform(0, 1, (8, 8)).astype(np.float32),
                            confidence=rng.uniform(0, 1, (3, 4, 4)).astype(np.float16),
                            F2=rng.normal(size=(64, 2, 2)).astype(np.float16),
                            F3=rng.normal(size=(160, 1, 1)).astype(np.float16))
    return meta


class ErrorCPU(unittest.TestCase):
    def test_histogram_perfect_reversed_and_ties(self):
        truth = np.array([False, False, True, True])
        mask = np.ones(4, bool)
        h = ErrorHistogram(10)
        h.update(np.array([0., 0., 1., 1.]), truth, mask)
        self.assertEqual(h.report()["average_precision_binned"], 1.0)
        tied = ErrorHistogram(10)
        tied.update(np.full(4, 0.5), truth, mask)
        self.assertEqual(tied.report()["average_precision_binned"], 0.5)
        self.assertAlmostEqual(tied.report()["recall_at_selected_fraction"]["0.1"], .1)
        empty = ErrorHistogram(10)
        empty.update(np.zeros(4), np.zeros(4, bool), mask)
        self.assertIsNone(empty.report()["average_precision_binned"])

    def test_interior_excludes_predicted_boundary(self):
        pred = np.zeros((15, 15), np.uint8)
        pred[:, 8:] = 1
        inside = interior_mask(pred, radius=1)
        self.assertTrue(inside[5, 4])
        self.assertFalse(inside[5, 7])
        self.assertFalse(inside[0, 4])

    def test_split_guard_and_bad_ignore(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            train = synthetic_cache(root / "train", ["city_000001_000001"])
            val = synthetic_cache(root / "val", ["city_000001_000002"])
            with self.assertRaises(ValueError):
                split_check(train, val)
            self.assertEqual(split_check(train, val, True), ["city_000001"])
            record = load_record(root / "train", train["images"][0], ["F2", "F3"])
            record["valid"][0, 0] = True
            np.savez(cache_path(root / "train", train["images"][0]), **record)
            with self.assertRaises(ValueError):
                load_record(root / "train", train["images"][0])


@unittest.skipUnless(importlib.util.find_spec("torch"), "PyTorch unavailable")
class ErrorTorch(unittest.TestCase):
    def test_detachment_and_sparse_ae_gradients(self):
        import torch
        from routing.error_head.model import ErrorHead, error_loss
        torch.set_num_threads(1)
        conf = torch.randn(1, 3, 4, 4, requires_grad=True)
        maps = {"F2": torch.randn(1, 64, 2, 2, requires_grad=True),
                "F3": torch.randn(1, 160, 1, 1, requires_grad=True)}
        for mode, sae in [("confidence", False), ("activations", False),
                          ("both", False), ("both", True)]:
            model = ErrorHead(mode, ("F2", "F3"), width=4, sparse_ae=sae, latent=3)
            logits, aux = model(conf, maps)
            target = torch.zeros_like(logits)
            target[:, 1:3, 1:3] = .5
            loss = error_loss(logits, target, torch.ones_like(target), .25)
            if sae:
                loss = loss + .1 * aux["reconstruction"].mean() + .001 * aux["latent_l1"]
            loss.backward()
            self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for p in model.parameters()))
            if sae:
                self.assertIsNotNone(model.decoder.weight.grad)
                self.assertIsNotNone(model.encoder[0].weight.grad)
            self.assertIsNone(conf.grad)
            self.assertTrue(all(x.grad is None for x in maps.values()))

    def test_pooled_error_fraction_and_ignored_loss(self):
        import torch
        from routing.error_head.model import pooled_target, error_loss
        record = {"b0": np.array([[1, 0], [0, 1]]), "gt": np.array([[0, 0], [255, 1]]),
                  "valid": np.array([[True, True], [False, True]])}
        target, weight = pooled_target(record, (1, 1), "cpu")
        self.assertAlmostEqual(target.item(), 1 / 3)
        self.assertAlmostEqual(weight.item(), 3 / 4)
        self.assertAlmostEqual(error_loss(torch.zeros_like(target), target, weight).item(),
                               np.log(2), places=6)
        logits = torch.zeros((1, 2, 2), requires_grad=True)
        w = torch.ones_like(logits)
        w[0, 0, 0] = 0
        error_loss(logits, torch.ones_like(logits), w).backward()
        self.assertEqual(logits.grad[0, 0, 0].item(), 0)
        self.assertNotEqual(logits.grad[0, 1, 1].item(), 0)

    def test_complete_cli_train_eval_and_frozen_thresholds(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            synthetic_cache(root / "train", ["train_000001_000001", "train_000002_000001"])
            synthetic_cache(root / "val", ["val_000001_000001"])
            synthetic_cache(root / "test", ["test_000001_000001"])
            def run(module, *args, succeeds=True):
                completed = subprocess.run([sys.executable, "-m", module, *map(str, args)],
                                           capture_output=True, text=True, env=os.environ.copy())
                if succeeds:
                    self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
                else:
                    self.assertNotEqual(completed.returncode, 0)
            run("routing.error_head.prepare", "--train", root / "train", "--out", root / "normalization")
            for name, mode, extra in [("confidence", "confidence", []),
                                     ("both", "both", []),
                                     ("sparse", "both", ["--sparse-ae"]),
                                     ("ohem", "both", ["--hard-fraction", "0.25"])]:
                run("routing.error_head.train", "--train", root / "train", "--val", root / "val",
                    "--out", root / name, "--normalization", root / "normalization", "--mode", mode,
                    "--epochs", 1, "--width", 4, "--latent", 3, "--device", "cpu", "--threads", 1, *extra)
                config = json.loads((root / name / "config.json").read_text())
                self.assertTrue(config["complete"])
                run("routing.error_head.evaluate", "--cache", root / "val", "--run", root / name,
                    "--out", root / f"{name}_val.json", "--routing", "--bins", 32, "--interior-radius", 0)
            cal = json.loads((root / "both_val.json").read_text())
            self.assertEqual(len(cal["routing_rows"]), 2)
            run("routing.error_head.evaluate", "--cache", root / "test", "--run", root / "both",
                "--out", root / "forbidden.json", "--routing", succeeds=False)
            run("routing.error_head.evaluate", "--cache", root / "test", "--run", root / "both",
                "--out", root / "test.json", "--routing", "--exploratory", "--calibration", root / "both_val.json")
            test = json.loads((root / "test.json").read_text())
            self.assertEqual([r["threshold"] for r in cal["routing_rows"]],
                             [r["threshold"] for r in test["routing_rows"]])
            # A changed checkpoint is rejected before inference.
            with (root / "both/head.pt").open("ab") as stream:
                stream.write(b"changed")
            run("routing.error_head.evaluate", "--cache", root / "val", "--run", root / "both",
                "--out", root / "changed.json", succeeds=False)


if __name__ == "__main__":
    unittest.main()
