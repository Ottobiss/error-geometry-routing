"""Fit activation normalization once on the selector-training split only."""
import argparse
from pathlib import Path
import numpy as np
from routing.frozen.common import write_json
from routing.error_head.data import checked_split, fit_normalization, file_hash


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--layers", default="F2,F3")
    args = ap.parse_args()
    layers = args.layers.split(",")
    if not layers or len(layers) != len(set(layers)):
        raise ValueError("Provide unique activation layers")
    if args.out.exists():
        raise ValueError("Use a fresh normalization output directory")
    meta = checked_split(args.train, layers)
    state = fit_normalization(args.train, meta, layers)
    args.out.mkdir(parents=True)
    np.savez(args.out / "normalization.npz", **state)
    write_json(args.out / "config.json", {
        "schema": "frozen-error-normalization-v1", "train_manifest": meta,
        "layers": layers, "sha256": file_hash(args.out / "normalization.npz")})
    print("Normalization saved:", args.out, flush=True)


if __name__ == "__main__":
    main()
