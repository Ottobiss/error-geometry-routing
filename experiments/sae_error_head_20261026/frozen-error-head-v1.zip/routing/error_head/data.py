"""Cache validation and train-only normalization. No torch/model imports."""
from pathlib import Path
import hashlib
import numpy as np

from routing.frozen.common import manifest, compatible, assert_disjoint, cache_path

CHANNELS = {"F2": 64, "F3": 160, "F4": 256, "C": 256}


def checked_split(root, layers=()):
    meta = manifest(root)
    if not set(layers) <= set(meta["layers"]):
        raise ValueError("Required activation layers are absent from cache")
    if len(meta["images"]) != len(set(meta["images"])):
        raise ValueError("Duplicate image IDs")
    for image_id in meta["images"]:
        if not cache_path(root, image_id).is_file():
            raise ValueError(f"Missing cache array for {image_id}")
    return meta


def sequence_id(image_id):
    return "_".join(image_id.split("_")[:2])


def split_check(train, val, allow_sequence_overlap=False):
    assert_disjoint(train, val)
    overlap = sorted({sequence_id(x) for x in train["images"]}
                     & {sequence_id(x) for x in val["images"]})
    if overlap and not allow_sequence_overlap:
        raise ValueError("Train/validation sequences overlap; choose grouped splits or explicitly "
                         "pass --allow-sequence-overlap for an exploratory run")
    return overlap


def load_record(root, image_id, layers=(), with_b2=False):
    keys = ["b0", "gt", "valid", "confidence", "entropy", *layers]
    if with_b2:
        keys += ["b2"]
    with np.load(cache_path(root, image_id), allow_pickle=False) as z:
        result = {k: z[k] for k in keys}
    shape = result["gt"].shape
    if result["b0"].shape != shape or result["valid"].shape != shape:
        raise ValueError("Inconsistent cache mask shapes")
    if not np.array_equal(result["valid"].astype(bool), result["gt"] != 255):
        raise ValueError("Cache ignore mask does not match ground truth")
    if not np.isin(result["gt"], list(range(19)) + [255]).all() or not np.isin(result["b0"], range(19)).all():
        raise ValueError("Expected Cityscapes train IDs 0..18 and ignore ID 255")
    if result["confidence"].ndim != 3 or result["confidence"].shape[0] != 3:
        raise ValueError("Expected three cached confidence maps")
    for key in ["confidence", "entropy", *layers]:
        if not np.isfinite(result[key]).all():
            raise ValueError(f"Nonfinite array: {key}")
    for layer in layers:
        if result[layer].ndim != 3 or result[layer].shape[0] != CHANNELS[layer]:
            raise ValueError(f"Unexpected shape for {layer}")
    return result


def fit_normalization(root, meta, layers):
    """Every channel uses all native-grid activations from TRAIN only."""
    sums = {k: np.zeros(CHANNELS[k], np.float64) for k in layers}
    sums2 = {k: np.zeros(CHANNELS[k], np.float64) for k in layers}
    counts = {k: 0 for k in layers}
    for index, image_id in enumerate(meta["images"]):
        with np.load(cache_path(root, image_id), allow_pickle=False) as z:
            for layer in layers:
                x = z[layer].astype(np.float64).reshape(CHANNELS[layer], -1)
                if not np.isfinite(x).all():
                    raise ValueError("Nonfinite training activations")
                sums[layer] += x.sum(1)
                sums2[layer] += np.square(x).sum(1)
                counts[layer] += x.shape[1]
        if (index + 1) % 40 == 0 or index + 1 == len(meta["images"]):
            print(f"normalization {index + 1}/{len(meta['images'])}", flush=True)
    state = {}
    for layer in layers:
        mean = sums[layer] / counts[layer]
        scale = np.sqrt(np.maximum(0, sums2[layer] / counts[layer] - mean ** 2)).clip(1e-4)
        state[layer + "_mean"] = mean.astype(np.float32)
        state[layer + "_scale"] = scale.astype(np.float32)
    return state


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_evaluation(meta, config, exploratory=False):
    train = config["train_manifest"]
    compatible(train, meta)
    if train["dataset"] != meta["dataset"]:
        raise ValueError("This experiment currently supports the same dataset/input policy only")
    if set(train["images"]) & set(meta["images"]):
        raise ValueError("Refusing evaluation on training images")
    is_val = set(meta["images"]) == set(config["val_manifest"]["images"])
    if not is_val and set(meta["images"]) & set(config["val_manifest"]["images"]):
        raise ValueError("Evaluation partially overlaps validation")
    if not is_val and not exploratory:
        raise ValueError("Non-validation evaluation needs --exploratory; do not tune on P1")
    return is_val
