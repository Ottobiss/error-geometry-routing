"""Small supervised error heads; detached cache inputs, no segmentators."""
import math
import torch
from torch import nn
from torch.nn import functional as F

from routing.error_head.data import CHANNELS


def pooled_target(record, size, device):
    valid = torch.as_tensor(record["valid"], device=device).float()[None, None]
    error = torch.as_tensor(record["b0"] != record["gt"], device=device).float()[None, None]
    weight = F.adaptive_avg_pool2d(valid, size)[:, 0]
    total = F.adaptive_avg_pool2d(error * valid, size)[:, 0]
    return total / weight.clamp_min(1e-8), weight


def inputs(record, layers, normalization, device):
    # The original cached confidence grid is used for every ablation.
    conf = torch.as_tensor(record["confidence"].astype("float32"), device=device)[None]
    conf = conf.detach().clone()
    conf[:, 0] /= math.log(19)
    maps = {}
    for layer in layers:
        x = torch.as_tensor(record[layer].astype("float32"), device=device)[None].detach()
        mean = torch.as_tensor(normalization[layer + "_mean"], device=device)[None, :, None, None]
        scale = torch.as_tensor(normalization[layer + "_scale"], device=device)[None, :, None, None]
        maps[layer] = (x - mean) / scale
    return conf, maps


class ErrorHead(nn.Module):
    def __init__(self, mode="both", layers=("F2", "F3"), width=16, sparse_ae=False, latent=16):
        super().__init__()
        if mode not in ("confidence", "activations", "both") or width < 1 or latent < 1:
            raise ValueError("Invalid head configuration")
        self.mode = mode
        self.layers = tuple(layers) if mode != "confidence" else ()
        self.sparse_ae = sparse_ae
        if (mode != "confidence" and not self.layers) or (sparse_ae and not self.layers):
            raise ValueError("Activation/autoencoder heads require activation layers")
        if sparse_ae:
            channels = sum(CHANNELS[k] for k in self.layers)
            self.encoder = nn.Sequential(nn.Conv2d(channels, latent, 1), nn.ReLU())
            self.decoder = nn.Conv2d(latent, channels, 1)
            channels_in = latent + 1  # latent plus per-location reconstruction residual
        else:
            self.project = nn.ModuleDict({k: nn.Sequential(
                nn.Conv2d(CHANNELS[k], width, 1), nn.GELU()) for k in self.layers})
            channels_in = width * len(self.layers)
        if mode != "activations":
            channels_in += 3
        self.classifier = nn.Sequential(
            nn.Conv2d(channels_in, width, 1), nn.GELU(),
            nn.Conv2d(width, width, 3, padding=1), nn.GELU(),
            nn.Conv2d(width, 1, 1))

    def forward(self, confidence, maps):
        size = confidence.shape[-2:]
        parts = [] if self.mode == "activations" else [confidence.detach()]
        aux = {}
        if self.sparse_ae:
            target = torch.cat([F.interpolate(maps[k].detach(), size, mode="bilinear",
                                              align_corners=False) for k in self.layers], dim=1)
            latent = self.encoder(target)
            reconstruction = (self.decoder(latent) - target).square().mean(1)
            aux = {"reconstruction": reconstruction, "latent_l1": latent.abs().mean(),
                   "latent_zero_fraction": (latent <= 1e-8).float().mean()}
            parts += [latent, reconstruction[:, None]]
        else:
            parts += [F.interpolate(self.project[k](maps[k].detach()), size, mode="bilinear",
                                    align_corners=False) for k in self.layers]
        return self.classifier(torch.cat(parts, dim=1))[:, 0], aux


def error_loss(logits, target, weight, hard_fraction=1.0):
    """BCE on soft error fractions; optional stratified hard spatial-cell mining.

    Mining is based on the error HEAD loss, never B0 entropy. Keep at least one
    nonzero-error cell and one zero-error cell when those groups exist. This is
    a documented OHEM-style adaptation, not a reproduction of detection OHEM.
    """
    if not 0 < hard_fraction <= 1:
        raise ValueError("hard_fraction must be in (0, 1]")
    loss = F.binary_cross_entropy_with_logits(logits, target, reduction="none")
    valid = weight > 0
    selected = valid
    if hard_fraction < 1:
        selected = torch.zeros_like(valid)
        for group in (valid & (target > 0), valid & (target == 0)):
            indices = torch.nonzero(group.flatten(), as_tuple=False).flatten()
            if indices.numel():
                count = max(1, math.ceil(indices.numel() * hard_fraction))
                chosen = indices[loss.flatten()[indices].detach().topk(count).indices]
                selected.flatten()[chosen] = True
    selected_weight = weight * selected
    return (loss * selected_weight).sum() / selected_weight.sum().clamp_min(1e-8)
