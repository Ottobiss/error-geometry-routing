"""Cached error detection and B2 routing diagnostics; no live-latency claims."""
import argparse
import math
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F

from routing.frozen.common import (read_json, write_json, boxes, tile_means,
                                   confusion, miou, compatible, components)
from routing.error_head.data import checked_split, load_record, check_evaluation, file_hash
from routing.error_head.model import ErrorHead, inputs
from routing.error_head.metrics import ErrorHistogram, interior_mask


def load_head(run, device):
    config = read_json(run / "config.json")
    if config.get("schema") != "frozen-error-head-v1" or not config.get("complete"):
        raise ValueError("Head training is incomplete or schema is incompatible")
    for filename, key in (("head.pt", "checkpoint_sha256"),
                          ("normalization.npz", "normalization_sha256")):
        if file_hash(run / filename) != config[key]:
            raise ValueError(f"Changed artifact: {filename}")
    model = ErrorHead(config["mode"], config["layers"], config["width"],
                      config["sparse_ae"], config["latent"]).to(device).eval()
    model.load_state_dict(torch.load(run / "head.pt", map_location=device,
                                    weights_only=True)["state_dict"])
    with np.load(run / "normalization.npz", allow_pickle=False) as z:
        normalization = {k: z[k] for k in z.files}
    return config, model, normalization


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", type=Path, required=True)
    ap.add_argument("--run", type=Path)
    ap.add_argument("--score", choices=("head", "entropy"), default="head")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--bins", type=int, default=4096)
    ap.add_argument("--interior-radius", type=int, default=3)
    ap.add_argument("--low-entropy", type=float, default=0.1)
    ap.add_argument("--component-error-fraction", type=float, default=0.2)
    ap.add_argument("--routing", action="store_true")
    ap.add_argument("--calibration", type=Path, help="Frozen validation report, required on P1")
    ap.add_argument("--target-windows", default="0.8,2.4")
    ap.add_argument("--exploratory", action="store_true")
    args = ap.parse_args()
    if args.out.exists():
        raise ValueError("Do not overwrite an evaluation report")
    if not 0 <= args.low_entropy <= 1 or not 0 < args.component_error_fraction <= 1:
        raise ValueError("Invalid diagnostic thresholds")
    torch.set_num_threads(args.threads)
    config, model, normalization = None, None, {}
    layers = []
    if args.score == "head":
        if not args.run:
            raise ValueError("--run is required for head evaluation")
        config, model, normalization = load_head(args.run, args.device)
        layers = config["layers"]
    meta = checked_split(args.cache, layers)
    is_val = check_evaluation(meta, config, args.exploratory) if config else None
    calibration = read_json(args.calibration) if args.calibration else None
    if calibration:
        compatible(calibration["cache_manifest"], meta)
        if calibration["score"] != args.score or calibration["run"] != (str(args.run) if args.run else None):
            raise ValueError("Calibration belongs to another scoring method")
        if calibration.get("exploratory") or not calibration.get("routing_rows"):
            raise ValueError("Need a validation routing report, not a test report")
        if set(calibration["cache_manifest"]["images"]) & set(meta["images"]):
            raise ValueError("Calibration/evaluation overlap")
        if config:
            if set(calibration["cache_manifest"]["images"]) != set(config["val_manifest"]["images"]):
                raise ValueError("Calibration is not from the model's validation split")
            if calibration.get("checkpoint_sha256") != config["checkpoint_sha256"]:
                raise ValueError("Checkpoint changed after calibration")
    if args.routing and args.exploratory and not calibration:
        raise ValueError("Exploratory P1 routing requires frozen validation thresholds")
    if args.routing and not args.exploratory and config and not is_val:
        raise ValueError("Fit thresholds on validation only")
    groups = {key: ErrorHistogram(args.bins) for key in
              ("all", "interior", "low_entropy", "low_entropy_interior", "components")}
    frames, brier_sum, valid_count = [], 0.0, 0
    ae_diagnostics = {key: [] for key in ("reconstruction_mse", "latent_l1", "latent_zero_fraction")}
    grid = boxes(meta["size"], meta["tile"])
    with torch.no_grad():
        for index, image_id in enumerate(meta["images"], 1):
            record = load_record(args.cache, image_id, layers, args.routing)
            entropy = np.clip(record["entropy"].astype(np.float32) / math.log(19), 0, 1)
            if model:
                conf, maps = inputs(record, layers, normalization, args.device)
                logits, aux = model(conf, maps)
                if aux:
                    ae_diagnostics["reconstruction_mse"].append(float(aux["reconstruction"].mean().item()))
                    ae_diagnostics["latent_l1"].append(float(aux["latent_l1"].item()))
                    ae_diagnostics["latent_zero_fraction"].append(float(aux["latent_zero_fraction"].item()))
                score = F.interpolate(logits.sigmoid()[:, None], record["gt"].shape,
                                      mode="bilinear", align_corners=False)[0, 0].cpu().numpy()
            else:
                score = entropy
            valid = record["valid"].astype(bool)
            errors = record["b0"] != record["gt"]
            interior = interior_mask(record["b0"], args.interior_radius)
            confident = entropy <= args.low_entropy
            masks = {"all": valid, "interior": valid & interior,
                     "low_entropy": valid & confident,
                     "low_entropy_interior": valid & interior & confident}
            for key, mask in masks.items():
                groups[key].update(score, errors, mask)
            # Components come from the entire B0 prediction, without entropy filtering.
            comp, classes = components(record["b0"])
            n = len(classes)
            count = np.bincount(comp[valid], minlength=n)
            err_count = np.bincount(comp[valid], weights=errors[valid], minlength=n)
            score_sum = np.bincount(comp[valid], weights=score[valid], minlength=n)
            has_labels = count > 0
            component_score = score_sum / np.maximum(count, 1)
            component_bad = err_count / np.maximum(count, 1) >= args.component_error_fraction
            groups["components"].update(component_score, component_bad, has_labels)
            if model:
                brier_sum += float(np.square(score[valid] - errors[valid]).sum(dtype=np.float64))
            valid_count += int(valid.sum())
            frame = {"image_id": image_id, "valid_pixels": int(valid.sum()),
                     "error_pixels": int((errors & valid).sum()),
                     "low_entropy_interior_errors": int((errors & masks["low_entropy_interior"]).sum())}
            if args.routing:
                frame["scores"] = tile_means(score, meta["size"], meta["tile"]).tolist()
                for key in ("b0", "b2"):
                    frame["conf_" + key] = np.stack([
                        confusion(record["gt"][y0:y1, x0:x1], record[key][y0:y1, x0:x1])
                        for x0, y0, x1, y1 in grid])
            frames.append(frame)
            if index % 20 == 0 or index == len(meta["images"]):
                print(f"evaluate {index}/{len(meta['images'])}", flush=True)
    if not valid_count:
        raise ValueError("Evaluation split has no valid pixels")
    routing_rows = []
    if args.routing:
        if calibration:
            points = [(r["target_validation_windows"], r["threshold"])
                      for r in calibration["routing_rows"]]
        else:
            values = np.concatenate([f["scores"] for f in frames])
            targets = [float(x) for x in args.target_windows.split(",")]
            if any(not 0 < t < len(grid) for t in targets):
                raise ValueError("Target windows must lie strictly between zero and the grid size")
            points = [(t, float(np.quantile(values, 1 - t / len(grid)))) for t in targets]
        for target, threshold in points:
            total = np.zeros((19, 19), np.int64)
            measurements = []
            for frame in frames:
                selected = np.asarray(frame["scores"]) > threshold
                matrix = np.where(selected[:, None, None], frame["conf_b2"], frame["conf_b0"]).sum(0)
                total += matrix
                measurements.append({"image_id": frame["image_id"], "windows": int(selected.sum()),
                                     "confusion": matrix.tolist()})
            routing_rows.append({"target_validation_windows": target, "threshold": threshold,
                                 "cached_miou": miou(total),
                                 "mean_windows": float(np.mean([f["windows"] for f in measurements])),
                                 "frames": measurements})
    for frame in frames:
        frame.pop("conf_b0", None)
        frame.pop("conf_b2", None)
    report = {"schema": "frozen-error-evaluation-v1", "score": args.score,
              "run": str(args.run) if args.run else None, "cache_manifest": meta,
              "checkpoint_sha256": config["checkpoint_sha256"] if config else None,
              "exploratory": args.exploratory,
              "diagnostics": {"bins": args.bins, "interior_radius_pixels": args.interior_radius,
                              "low_normalized_entropy_threshold": args.low_entropy,
                              "component_bad_if_error_fraction_at_least": args.component_error_fraction},
              "metrics": {key: value.report() for key, value in groups.items()},
              "pixel_brier": brier_sum / valid_count if model and valid_count else None,
              "autoencoder_diagnostics": {k: float(np.mean(v)) if v else None for k, v in ae_diagnostics.items()},
              "routing_rows": routing_rows, "frames": frames,
              "note": "Histogram AP/recall are approximations. Components are equally weighted; "
                      "pixel masks use valid GT only for evaluation. Cached routing has NO latency measurement. "
                      "Error detection is not B2 gain prediction. No segmentation model is loaded."}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    write_json(args.out, report)
    print({"metrics": report["metrics"], "pixel_brier": report["pixel_brier"],
           "routing": [{k: v for k, v in r.items() if k != "frames"} for r in routing_rows]}, flush=True)


if __name__ == "__main__":
    main()
