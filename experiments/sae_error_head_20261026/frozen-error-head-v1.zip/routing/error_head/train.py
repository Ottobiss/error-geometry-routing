"""Train only an error head on cached B0 activations. No B0/B2 are constructed."""
import argparse
import os
import random
import shutil
from pathlib import Path

import numpy as np
import torch

from routing.frozen.common import read_json, write_json, compatible
from routing.error_head.data import checked_split, split_check, load_record, file_hash
from routing.error_head.model import ErrorHead, inputs, pooled_target, error_loss


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--val", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--normalization", type=Path)
    ap.add_argument("--mode", choices=("confidence", "activations", "both"), default="both")
    ap.add_argument("--layers", default="F2,F3")
    ap.add_argument("--width", type=int, default=16)
    ap.add_argument("--latent", type=int, default=16)
    ap.add_argument("--sparse-ae", action="store_true")
    ap.add_argument("--reconstruction-weight", type=float, default=0.1)
    ap.add_argument("--sparsity-weight", type=float, default=0.001)
    ap.add_argument("--hard-fraction", type=float, default=1.0)
    ap.add_argument("--epochs", type=int, default=8)
    ap.add_argument("--patience", type=int, default=3)
    ap.add_argument("--lr", type=float, default=0.001)
    ap.add_argument("--weight-decay", type=float, default=0.0001)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--allow-sequence-overlap", action="store_true")
    args = ap.parse_args()
    if args.epochs < 1 or args.patience < 1 or args.threads < 1 or args.lr <= 0:
        raise ValueError("Positive epochs, patience, threads and learning rate required")
    if min(args.reconstruction_weight, args.sparsity_weight, args.weight_decay) < 0:
        raise ValueError("Loss and regularization weights must be nonnegative")
    if not 0 < args.hard_fraction <= 1:
        raise ValueError("hard-fraction must be in (0, 1]")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA unavailable; use --device cpu explicitly")
    if args.out.exists():
        raise ValueError("Use a fresh run directory; previous experiments are immutable")
    torch.set_num_threads(args.threads)
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    layers = args.layers.split(",") if args.mode != "confidence" else []
    if len(layers) != len(set(layers)):
        raise ValueError("Duplicate activation layers")
    tm = checked_split(args.train, layers)
    vm = checked_split(args.val, layers)
    overlap = split_check(tm, vm, args.allow_sequence_overlap)
    if overlap:
        print("WARNING: exploratory train/validation sequence overlap:", overlap, flush=True)
    normalization = {}
    if layers:
        if not args.normalization:
            raise ValueError("Fit train-only normalization with routing.error_head.prepare first")
        nm = read_json(args.normalization / "config.json")
        compatible(nm["train_manifest"], tm)
        if set(nm["train_manifest"]["images"]) != set(tm["images"]):
            raise ValueError("Normalization was not fitted on this training split")
        if not set(layers) <= set(nm["layers"]):
            raise ValueError("Missing normalization layers")
        if file_hash(args.normalization / "normalization.npz") != nm["sha256"]:
            raise ValueError("Normalization checksum mismatch")
        with np.load(args.normalization / "normalization.npz", allow_pickle=False) as z:
            normalization = {k: z[k] for k in z.files}
    model = ErrorHead(args.mode, layers, args.width, args.sparse_ae, args.latent).to(args.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    assert {id(p) for group in optimizer.param_groups for p in group["params"]} == {
        id(p) for p in model.parameters() if p.requires_grad}
    args.out.mkdir(parents=True)
    np.savez(args.out / "normalization.npz", **normalization)
    if layers:
        shutil.copy2(args.normalization / "config.json", args.out / "normalization_config.json")
    config = {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()}
    config.update({"schema": "frozen-error-head-v1", "layers": layers,
                   "train_manifest": tm, "val_manifest": vm,
                   "train_validation_sequence_overlap": overlap,
                   "target": "B0 error fraction among valid pixels in each confidence-grid cell",
                   "checkpoint_selection": "minimum ordinary validation BCE; no OHEM in validation",
                   "trainable_parameters": sum(p.numel() for p in model.parameters()),
                   "normalization_sha256": file_hash(args.out / "normalization.npz"),
                   "complete": False})
    write_json(args.out / "config.json", config)
    print({"device": args.device, "trainable_parameters": config["trainable_parameters"],
           "mode": args.mode, "sparse_ae": args.sparse_ae,
           "note": "No segmentation model exists in this process; only the head is trained"}, flush=True)
    history = []
    rng = np.random.default_rng(args.seed)
    best, best_epoch = float("inf"), 0
    for epoch in range(1, args.epochs + 1):
        metrics = {}
        for split, root, meta in (("train", args.train, tm), ("val", args.val, vm)):
            training = split == "train"
            model.train(training)
            order = rng.permutation(len(meta["images"])) if training else range(len(meta["images"]))
            sums = {k: 0.0 for k in ("bce", "objective", "reconstruction", "latent_l1", "latent_zero_fraction", "weight")}
            with torch.set_grad_enabled(training):
                for step, index in enumerate(order, 1):
                    record = load_record(root, meta["images"][index], layers)
                    conf, maps = inputs(record, layers, normalization, args.device)
                    logits, aux = model(conf, maps)
                    target, weight = pooled_target(record, logits.shape[-2:], args.device)
                    if weight.sum().item() == 0:
                        continue
                    bce = error_loss(logits, target, weight)
                    objective = error_loss(logits, target, weight,
                                           args.hard_fraction if training else 1.0)
                    reconstruction = aux["reconstruction"].mean() if aux else logits.new_zeros(())
                    sparsity = aux["latent_l1"] if aux else logits.new_zeros(())
                    zero_fraction = aux["latent_zero_fraction"] if aux else logits.new_zeros(())
                    objective = objective + args.reconstruction_weight * reconstruction + args.sparsity_weight * sparsity
                    if not torch.isfinite(objective):
                        raise FloatingPointError("Nonfinite training/evaluation loss")
                    if training:
                        optimizer.zero_grad(set_to_none=True)
                        objective.backward()
                        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                        optimizer.step()
                    n = float(weight.sum().item())
                    for key, value in (("bce", bce), ("objective", objective),
                                       ("reconstruction", reconstruction), ("latent_l1", sparsity),
                                       ("latent_zero_fraction", zero_fraction)):
                        sums[key] += float(value.detach().item()) * n
                    sums["weight"] += n
                    if step % 40 == 0 or step == len(meta["images"]):
                        print(f"epoch {epoch} {split} {step}/{len(meta['images'])}", flush=True)
            if sums["weight"] == 0:
                raise ValueError("Split has no valid ground-truth pixels")
            metrics.update({split + "_" + k: sums[k] / sums["weight"]
                            for k in sums if k != "weight"})
        row = {"epoch": epoch, **metrics}
        history.append(row)
        print(row, flush=True)
        write_json(args.out / "history.json", history)
        if metrics["val_bce"] < best:
            best, best_epoch = metrics["val_bce"], epoch
            torch.save({"state_dict": model.state_dict()}, args.out / "head.pt")
        if epoch - best_epoch >= args.patience:
            break
    config.update({"complete": True, "best_epoch": best_epoch, "best_val_bce": best,
                   "epochs_completed": len(history), "checkpoint_sha256": file_hash(args.out / "head.pt")})
    write_json(args.out / "config.json", config)
    print("TRAINING COMPLETE:", args.out, flush=True)


if __name__ == "__main__":
    main()
