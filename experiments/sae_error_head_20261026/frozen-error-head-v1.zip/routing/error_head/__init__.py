"""Error detection on frozen B0 caches; segmentators are never trained here."""
