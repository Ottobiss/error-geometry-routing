"""Streaming, binned error-detection metrics and prediction-only interior masks."""
import numpy as np
from scipy import ndimage


class ErrorHistogram:
    def __init__(self, bins=4096):
        if bins < 2:
            raise ValueError("At least two score bins required")
        self.positive = np.zeros(bins, np.int64)
        self.negative = np.zeros(bins, np.int64)

    def update(self, scores, errors, mask):
        scores = np.asarray(scores)[mask]
        errors = np.asarray(errors, bool)[mask]
        if not np.isfinite(scores).all() or np.any(scores < 0) or np.any(scores > 1):
            raise ValueError("Scores must be finite and in [0,1]")
        indices = np.minimum((scores * len(self.positive)).astype(np.int64), len(self.positive) - 1)
        self.positive += np.bincount(indices[errors], minlength=len(self.positive))
        self.negative += np.bincount(indices[~errors], minlength=len(self.positive))

    def report(self):
        tp = np.cumsum(self.positive[::-1]).astype(float)
        fp = np.cumsum(self.negative[::-1]).astype(float)
        positives = int(self.positive.sum())
        total = positives + int(self.negative.sum())
        result = {"pixels": total, "errors": positives,
                  "error_prevalence": positives / total if total else None,
                  "average_precision_binned": None, "recall_at_selected_fraction": {}}
        if not positives:
            return result
        precision = tp / np.maximum(tp + fp, 1)
        result["average_precision_binned"] = float(
            np.sum(np.diff(np.r_[0, tp / positives]) * precision))
        counts = tp + fp
        for coverage in (0.01, 0.05, 0.1, 0.2):
            # Expected recall if ties within one histogram bin are selected uniformly.
            recalled = np.interp(coverage * total, np.r_[0, counts], np.r_[0, tp])
            result["recall_at_selected_fraction"][str(coverage)] = float(recalled / positives)
        return result


def interior_mask(prediction, radius=3):
    if radius < 0:
        raise ValueError("Nonnegative boundary radius required")
    pred = np.asarray(prediction)
    boundary = np.zeros(pred.shape, bool)
    different = pred[1:] != pred[:-1]
    boundary[1:] |= different
    boundary[:-1] |= different
    different = pred[:, 1:] != pred[:, :-1]
    boundary[:, 1:] |= different
    boundary[:, :-1] |= different
    boundary[[0, -1], :] = True
    boundary[:, [0, -1]] = True
    return ndimage.distance_transform_edt(~boundary) > radius
