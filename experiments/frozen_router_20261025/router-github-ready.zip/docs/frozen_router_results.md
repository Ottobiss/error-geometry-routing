# Frozen router experiments — 2026-10-25

This snapshot contains the supplied notebook, source code, selector checkpoints,
geometry reference statistics, split IDs, cache manifests, logs, validation
calibrations, P1 measurements, paired bootstrap and repeatability comparison.
Original uploaded archives and the environment listing are preserved in `exports/`.

## Setup

B0 and B2 are frozen pretrained Cityscapes segmentators. Only selectors are fitted.
The 500 Cityscapes validation images are divided into 240 selector-training,
60 internal-validation and 200 P1 evaluation images. P1 has been inspected in
earlier experiments; these comparisons are exploratory, not independent final
test results. Raw images and per-image feature caches are not included in the
supplied archives.

`notebooks/router.ipynb` is the original supplied notebook, including saved outputs.
The latest source from `router_results.zip` takes precedence over the stage-one
backup where the archives overlap. Configurations retain original DataSphere
paths; adjust paths when reproducing on another machine.

## Geometry finalist and P1

At 2.4 mean B2 windows/image on internal validation, Mahalanobis F3 reached
76.1982 mIoU versus 75.6272 for the same component ridge selector without geometry
(+0.5710 percentage points). Against raw entropy, the validation gain was +0.4546.
Thresholds were then fixed, without tuning on P1.

| Method | P1 mIoU | Mean windows/image | First mean ms | Repeat mean ms |
|---|---:|---:|---:|---:|
| ridge_base | 79.7910 | 2.825 | 463.3833 | 462.8290 |
| mahalanobis_F3 | 79.6743 | 2.715 | 965.1143 | 967.3994 |
| raw_entropy | 79.9009 | 2.735 | 380.8648 | 380.9597 |

The repeat used the same fixed weights, thresholds and 200 images. Per-frame
confusion matrices and window counts matched for every image; mean runtime
changed by less than 0.24%. This checks repeatability, not independent generalization.

For F3 minus ridge_base, the sequence-level paired bootstrap 95% interval was
[-0.468, +0.136] percentage points. For F3 minus raw_entropy it was
[-1.535, -0.050]. The corresponding point differences were -0.117 and -0.227.
The validation improvement did not transfer to P1. Raw entropy remains the
preferred tested router. This conclusion is limited to the evaluated scheme.

## Timing scope

Tesla T4, FP32; each image receives three warmup executions and two measured
executions. Runtime includes B0, feature transfers, selector/geometry, selected
B2 windows and transfer to the CPU output mask; it excludes disk loading and
preprocessing. Runtime p95 is computed across per-image mean measured times.
Equal window counts do not imply equal total latency. Geometry calculations in
this prototype add CPU overhead. No GPU retraining is performed by the live
evaluation command.

## Files

- `routing/frozen/`, `core/`, `tests/`: supplied implementation and tests.
- `splits/frozen_router_v1/`: train, validation and P1 IDs.
- `results/frozen/routing_v1_20261025_132318/selectors_v1/`: spatial selectors,
  calibrations and first-stage results.
- `results/frozen/routing_v1_20261025_132318/geometry_v1/`: all five ridge variants,
  reference statistics, validation, P1 and repeat outputs.
- `exports/`: original archives, stage-one SHA256 and environment listing.

The stage-one ZIP SHA256 was verified against the supplied checksum before
extraction. `artifact_sha256.json` lists checksums for the published snapshot.
