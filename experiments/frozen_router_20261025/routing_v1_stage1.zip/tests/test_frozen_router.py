"""CPU numerical/integration tests; optional torch tests require the GPU environment."""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

from routing.frozen.common import (assert_disjoint, boxes, cache_path, confusion, manifest, merge_tiles,
                                   miou, ridge_fit, ridge_predict, window_origin, write_json)
from routing.frozen.geometry import distances, fit_geometry, native_labels
from routing.frozen.regional import components, features, targets


def meta(ids):
    return {"schema": 1, "complete": True, "dataset": "synthetic", "images": ids,
            "b0": "fake-b0", "b2": "fake-b2", "b0_revision": "a", "b2_revision": "b",
            "size": [4, 4], "tile": 2, "margin": 0, "b2_input": "small", "layers": ["F2"],
            "precision": "fp32"}


def record(seed=0):
    rng = np.random.default_rng(seed)
    b0 = np.array([[0, 0, 1, 1], [0, 0, 1, 1], [2, 2, 3, 3], [2, 2, 3, 3]], np.uint8)
    gt = b0.copy(); gt[0, 0] = 1; gt[3, 3] = 0; gt[0, 3] = 255
    b2 = gt.copy(); b2[0, 3] = 1; b2[2, 2] = 1
    valid = gt != 255
    gain = ((b2 == gt).astype(np.int8) - (b0 == gt).astype(np.int8)) * valid
    return {"b0": b0, "b2": b2, "gt": gt, "valid": valid, "gain": gain,
            "entropy": rng.random((4, 4)).astype(np.float32),
            "confidence": rng.random((3, 1, 1)).astype(np.float16),
            "F2": rng.normal(size=(2, 2, 2)).astype(np.float16)}


class FrozenCPU(unittest.TestCase):
    def test_components_eight_connected(self):
        comp, cls = components(np.array([[0, 1], [1, 0]]))
        self.assertEqual(len(cls), 2)
        self.assertEqual(comp[0, 0], comp[1, 1])

    def test_ridge_weighted_fit(self):
        x = np.arange(10, dtype=float)[:, None]
        y = 2 * x[:, 0] - 3
        fit = ridge_fit(x, y, np.ones(10), 1e-10)
        np.testing.assert_allclose(ridge_predict(fit, x), y, atol=1e-7)

    def test_ridge_rejects_nonfinite(self):
        with self.assertRaises(ValueError):
            ridge_fit(np.array([[np.nan]]), np.array([0]), np.array([1]))

    def test_split_overlap(self):
        with self.assertRaises(ValueError):
            assert_disjoint(meta(["a"]), meta(["a"]))
        assert_disjoint(meta(["a"]), meta(["b"]))

    def test_cache_policy_mismatch(self):
        a, b = meta(["a"]), meta(["b"])
        b["margin"] = 64
        with self.assertRaises(ValueError):
            assert_disjoint(a, b)

    def test_component_target_matches_signed_pixels(self):
        r = record()
        _, comp, _ = features(r)
        y, n = targets(r, comp)
        self.assertEqual(int(np.dot(y, n)), int(r["gain"].sum()))
        r2 = {k: v for k, v in r.items() if k not in ("gt", "gain", "valid", "b2")}
        # Inference features must not depend on ground truth/heavy output.
        np.testing.assert_array_equal(features(r2, ["F2"])[0], features(r, ["F2"])[0])

    def test_merge_zero_and_all(self):
        r = record()
        pred, n = merge_tiles(r["b0"], r["b2"], np.ones(4), 1, [4, 4], 2)
        np.testing.assert_array_equal(pred, r["b0"])
        self.assertEqual(n, 0)
        pred, n = merge_tiles(r["b0"], r["b2"], np.ones(4), 0, [4, 4], 2)
        np.testing.assert_array_equal(pred, r["b2"])
        self.assertEqual(n, 4)

    def test_window_origin_boundaries(self):
        self.assertEqual(window_origin((8, 8, 10, 10), [10, 10], 2, 1), (6, 6))
        with self.assertRaises(ValueError):
            window_origin((0, 0, 2, 2), [2, 2], 2, 1)

    def test_ignore_confusion(self):
        self.assertEqual(miou(confusion(np.array([[0, 255]]), np.array([[0, 1]]))), 100)

    def test_purity_and_ignore(self):
        gt = np.array([[1, 1, 255, 255], [1, 1, 255, 255]])
        np.testing.assert_array_equal(native_labels(gt, (1, 2)), [[1, 255]])

    def test_mahalanobis_matches_direct_inverse(self):
        rng = np.random.default_rng(4)
        x = rng.normal(size=(30, 4)); labels = np.arange(30) % 2
        state = fit_geometry(x, labels)
        z = (x - state["mean"]) / state["scale"]
        residual = z - state["centers"][labels]
        cov = residual.T @ residual / len(x) + 1e-3 * np.eye(4)
        delta = z - state["centers"][0]
        expected = np.einsum('nd,df,nf->n', delta, np.linalg.inv(cov), delta)
        np.testing.assert_allclose(distances(x, state, "mahalanobis")[:, 0], expected, atol=1e-9)

    def test_geometry_missing_classes_finite_features(self):
        r = record()
        rng = np.random.default_rng(2)
        state = fit_geometry(rng.normal(size=(20, 2)), np.zeros(20, dtype=int))
        x, _, _ = features(r, ["F2"], geometry={"F2": state})
        self.assertTrue(np.isfinite(x).all())

    def test_incomplete_cache_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            m = meta(["a"]); m["complete"] = False
            write_json(Path(td) / "manifest.json", m)
            with self.assertRaises(ValueError):
                manifest(td)

    def test_geometry_cli_and_selector_synthetic(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for name, ids in (("train", ["a", "b"]), ("val", ["c", "d"])):
                p = root / name; p.mkdir()
                write_json(p / "manifest.json", meta(ids))
                for i, image_id in enumerate(ids):
                    np.savez(cache_path(p, image_id), **record(i))
            subprocess.run([sys.executable, "-m", "routing.frozen.geometry", "--ref", str(root / "train"),
                            "--layers", "F2", "--out", str(root / "geometry")], check=True, capture_output=True)
            subprocess.run([sys.executable, "-m", "routing.frozen.train", "--train", str(root / "train"),
                            "--val", str(root / "val"), "--out", str(root / "run"), "--layers", "F2",
                            "--geometry", str(root / "geometry"), "--metric", "mahalanobis"],
                           check=True, capture_output=True)
            from routing.frozen.predict import Predictor
            score = Predictor(root / "run").score(record())
            self.assertEqual(score.shape, (4, 4))
            self.assertTrue(np.isfinite(score).all())

    def test_cli_train_and_calibrate_synthetic(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for name, ids in (("train", ["a", "b"]), ("val", ["c", "d"])):
                p = root / name; p.mkdir()
                write_json(p / "manifest.json", meta(ids))
                for i, image_id in enumerate(ids):
                    np.savez(cache_path(p, image_id), **record(i))
            run = root / "run"
            subprocess.run([sys.executable, "-m", "routing.frozen.train", "--train", str(root / "train"),
                            "--val", str(root / "val"), "--out", str(run), "--layers", "F2"],
                           check=True, capture_output=True, text=True)
            subprocess.run([sys.executable, "-m", "routing.frozen.calibrate", "--cache", str(root / "val"),
                            "--run", str(run), "--out", str(root / "thresholds.json")],
                           check=True, capture_output=True, text=True)
            rows = json.loads((root / "thresholds.json").read_text())["rows"]
            self.assertEqual(rows[0]["mean_windows"], 0)
            self.assertEqual(rows[-1]["mean_windows"], 4)


@unittest.skipUnless(importlib.util.find_spec("torch"), "PyTorch unavailable in this environment")
class FrozenTorch(unittest.TestCase):
    def test_head_gradients_and_ignore_mask(self):
        import torch
        from routing.frozen.head import SpatialSelector, masked_mse, target_at_grid
        head = SpatialSelector(["F2", "F3"])
        confidence = torch.randn(1, 3, 8, 8, requires_grad=True)
        maps = {"F2": torch.randn(1, 64, 4, 4, requires_grad=True),
                "F3": torch.randn(1, 160, 2, 2, requires_grad=True)}
        valid = torch.ones(1, 32, 32)
        gain = torch.ones_like(valid)
        target, weight = target_at_grid(gain, valid, (8, 8))
        loss = masked_mse(head(confidence, maps), target, weight)
        loss.backward()
        self.assertIsNone(confidence.grad)
        self.assertTrue(all(v.grad is None for v in maps.values()))
        self.assertTrue(any(p.grad is not None for p in head.parameters()))
        self.assertEqual(float(masked_mse(torch.ones(1), torch.zeros(1), torch.zeros(1))), 0)


if __name__ == "__main__":
    unittest.main()
