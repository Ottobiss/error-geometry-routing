"""True B0 -> selector -> selected B2 windows; includes CPU routing and mask transfer."""
import argparse
import time
from pathlib import Path

import numpy as np
import torch

from core.data import DATASETS, loader
from core.models import CHECKPOINTS
from routing.frozen.backbone import FrozenB0, load_b2, b2_windows, b2_predict
from routing.frozen.common import confusion, miou, read_json, tile_means, boxes, write_json
from routing.frozen.predict import Predictor


def signature_check(predictor, args, b0, b2):
    if not predictor.config:
        return
    train = predictor.config["train_manifest"]
    if train["dataset"] != args.dataset and not args.allow_domain_shift:
        raise ValueError("New domain requires --allow-domain-shift; do not retune on this evaluation")
    for key, actual in (("b0", args.b0), ("b2", args.b2), ("b0_revision", b0.revision),
                        ("b2_revision", b2._frozen_revision), ("tile", args.tile),
                        ("margin", args.margin), ("precision", args.precision)):
        if train[key] != actual:
            raise ValueError(f"Live/checkpoint mismatch: {key}")
    if train["dataset"] == args.dataset and (train["b2_input"] != args.b2_input or train["size"] != list(DATASETS[args.dataset].size)):
        raise ValueError("Live input policy differs from training")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=DATASETS, default="cityscapes")
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--split", choices=("train", "val", "test"), default="val")
    ap.add_argument("--ids", type=Path, required=True)
    ap.add_argument("--run", type=Path)
    ap.add_argument("--mode", choices=("learned", "entropy", "b0", "b2"), default="learned")
    ap.add_argument("--threshold", type=float)
    ap.add_argument("--calibration", type=Path, help="Validation threshold grid, for validation ONLY")
    ap.add_argument("--validation-sweep", action="store_true")
    ap.add_argument("--b0", default=CHECKPOINTS["b0"])
    ap.add_argument("--b2", default=CHECKPOINTS["b2"])
    ap.add_argument("--b2-input", choices=("image", "small"), default="image")
    ap.add_argument("--tile", type=int, default=256)
    ap.add_argument("--margin", type=int, default=64)
    ap.add_argument("--max-batch", type=int, default=2)
    ap.add_argument("--precision", choices=("fp32", "fp16"), default="fp32")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--warmup", type=int, default=3)
    ap.add_argument("--repeats", type=int, default=2)
    ap.add_argument("--allow-domain-shift", action="store_true", help="Explicitly evaluate a new dataset/input policy")
    ap.add_argument("--local-only", action="store_true")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    if args.device != "cuda" or not torch.cuda.is_available():
        raise ValueError("Live timing requires CUDA; cached evaluation is a different measurement")
    if args.max_batch < 1 or args.repeats < 1 or args.warmup < 1:
        raise ValueError("Positive max-batch/repeats/warmup required")
    if args.out.exists():
        raise ValueError("Do not overwrite an existing measurement")
    cls = DATASETS[args.dataset]
    cls.root = args.root
    ids = args.ids.read_text().split()
    if not ids or len(ids) != len(set(ids)):
        raise ValueError("Image ids must be unique and nonempty")
    ds = cls(ids=ids, full=args.b2_input == "image", split=args.split)
    if set(ds.image_ids) != set(ids):
        raise ValueError("Requested ids were not found")
    predictor = Predictor(args.run, args.device, "entropy" if args.mode != "learned" else "learned")
    thresholds = [args.threshold]
    if args.mode in ("learned", "entropy"):
        if args.calibration:
            if not args.validation_sweep:
                raise ValueError("Threshold sweep is allowed on validation only")
            cal = read_json(args.calibration)
            if cal["mode"] != args.mode or cal["run"] != (str(args.run) if args.run else None):
                raise ValueError("Calibration belongs to a different selector")
            if set(cal["validation"]["images"]) != set(ids) or cal["validation"]["dataset"] != args.dataset:
                raise ValueError("Refusing threshold sweep on different/test images")
            thresholds = [row["threshold"] for row in cal["rows"]]
        elif args.threshold is None:
            raise ValueError("Supply a fixed threshold, or a validation-only sweep")
    b0 = FrozenB0(args.b0, args.local_only).to(args.device) if args.mode != "b2" else None
    b2 = load_b2(args.b2, args.local_only, args.device) if args.mode != "b0" else None
    signature_check(predictor, args, b0, b2)
    if predictor.config and not args.validation_sweep:
        tm = predictor.config["train_manifest"]
        if args.dataset == tm["dataset"] and set(ids) & set(tm["images"]):
            raise ValueError("Evaluation images overlap training")
    all_rows = []
    grid = boxes(cls.size, args.tile)

    @torch.no_grad()
    def execute(sample, threshold):
        if args.mode == "b2":
            with torch.autocast("cuda", dtype=torch.float16, enabled=args.precision == "fp16"):
                pred = b2_predict(b2, sample[args.b2_input][None], cls.size)[0]
            return pred.to(torch.uint8).cpu().numpy(), 0
        layers = predictor.layers if args.mode == "learned" else []
        result = b0(sample["small"][None], cls.size, layers)
        pred = result["pred"][0].to(torch.uint8).cpu().numpy()
        if args.mode == "b0":
            return pred, 0
        # Same float16 feature quantization as the exported training cache.
        r = {"b0": pred, "entropy": result["entropy"][0].cpu().numpy(),
             "confidence": result["confidence"][0].half().cpu().numpy()}
        r.update({k: v[0].half().cpu().numpy() for k, v in result["maps"].items()})
        scores = tile_means(predictor.score(r), cls.size, args.tile)
        selected = np.flatnonzero(scores > threshold).tolist()
        if selected:
            tiled = b2_windows(b2, sample[args.b2_input], cls.size, selected, args.tile, args.margin,
                               args.max_batch, args.precision).cpu().numpy()
            for k in selected:
                x0, y0, x1, y1 = grid[k]
                pred[y0:y1, x0:x1] = tiled[y0:y1, x0:x1]
        return pred, len(selected)

    for threshold in thresholds:
        stats = {"conf": np.zeros((19, 19), np.int64), "times": [], "windows": [], "frames": [], "peak": []}
        for sample in loader(ds, args.workers):
            gt = sample.pop("label").numpy()
            image_id = sample["image_id"]
            sample = {k: v.to(args.device) if torch.is_tensor(v) else v for k, v in sample.items()}
            # Warm all executed shapes/policies for this frame outside timed repetitions.
            for _ in range(args.warmup):
                execute(sample, threshold)
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            times = []
            for _ in range(args.repeats):
                torch.cuda.synchronize()
                start = time.perf_counter()
                pred, n = execute(sample, threshold)
                torch.cuda.synchronize()
                times.append((time.perf_counter() - start) * 1000)
            elapsed = float(np.mean(times))
            stats["conf"] += confusion(gt, pred)
            stats["times"].append(elapsed); stats["windows"].append(n)
            stats["peak"].append(torch.cuda.max_memory_allocated())
            stats["frames"].append({"image_id": image_id, "ms": elapsed, "repeat_ms": times, "windows": n,
                                    "confusion": confusion(gt, pred).tolist()})
        all_rows.append({"threshold": threshold, "miou": miou(stats["conf"]),
                         "mean_ms": float(np.mean(stats["times"])), "median_ms": float(np.median(stats["times"])),
                         "p95_ms": float(np.percentile(stats["times"], 95)), "mean_windows": float(np.mean(stats["windows"])),
                         "peak_allocated_bytes": int(max(stats["peak"])), "frames": stats["frames"]})
        print({k: v for k, v in all_rows[-1].items() if k != "frames"}, flush=True)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    write_json(args.out, {"config": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
                          "gpu": torch.cuda.get_device_name(), "torch": torch.__version__,
                          "b0_revision": b0.revision if b0 is not None else None,
                          "b2_revision": b2._frozen_revision if b2 is not None else None,
                          "timing_scope": "GPU-resident input to CPU mask; includes transfers, features, selector and B2; excludes disk/preprocessing",
                          "rows": all_rows})


if __name__ == "__main__":
    main()
