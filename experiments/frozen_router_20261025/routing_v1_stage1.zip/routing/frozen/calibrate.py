"""Generate fixed thresholds on validation only. Cached metrics are NOT live latency."""
import argparse
from pathlib import Path

import numpy as np

from routing.frozen.common import (manifest, compatible, cache_path, confusion, miou, tile_means,
                                   merge_tiles, write_json)
from routing.frozen.predict import Predictor


def check_model_cache(predictor, meta, allow_shift=False):
    if predictor.config is None:
        return
    train = predictor.config["train_manifest"]
    if allow_shift:
        for key in ("b0", "b2", "b0_revision", "b2_revision", "layers", "tile", "margin", "precision"):
            if train[key] != meta[key]:
                raise ValueError(f"Checkpoint/cache mismatch: {key}")
    else:
        compatible(train, meta)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", type=Path, required=True)
    ap.add_argument("--run", type=Path)
    ap.add_argument("--mode", choices=("learned", "entropy"), default="learned")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--quantiles", default="0.5,0.6,0.7,0.8,0.9,0.95")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    meta = manifest(args.cache)
    predictor = Predictor(args.run, args.device, args.mode)
    check_model_cache(predictor, meta)
    if predictor.config:
        expected = predictor.config["val_manifest"]
        if meta["dataset"] != expected["dataset"] or meta["images"] != expected["images"]:
            raise ValueError("Calibrate on the declared validation split, not train/test")
    frames = []
    for image_id in meta["images"]:
        with np.load(cache_path(args.cache, image_id)) as z:
            r = {k: z[k] for k in z.files}
        scores = tile_means(predictor.score(r), meta["size"], meta["tile"])
        frames.append((r, scores))
    values = np.concatenate([s for _, s in frames])
    cuts = [float(np.nextafter(values.max(), np.asarray(np.inf, dtype=values.dtype))),
            float(np.nextafter(values.min(), np.asarray(-np.inf, dtype=values.dtype)))]
    qs = list(map(float, args.quantiles.split(",")))
    if not all(0 <= q <= 1 for q in qs):
        raise ValueError("Quantiles must be in [0,1]")
    cuts += [float(np.quantile(values, q)) for q in qs]
    rows = []
    for threshold in sorted(set(cuts), reverse=True):
        conf = np.zeros((19, 19), np.int64)
        counts = []
        for r, scores in frames:
            pred, n = merge_tiles(r["b0"], r["b2"], scores, threshold, meta["size"], meta["tile"])
            conf += confusion(r["gt"], pred)
            counts.append(n)
        rows.append({"threshold": threshold, "cached_miou": miou(conf), "mean_windows": float(np.mean(counts))})
    write_json(args.out, {"mode": args.mode, "run": str(args.run) if args.run else None,
                          "validation": meta, "rows": rows,
                          "note": "Choose final point using validation LIVE time; never tune on test"})
    print(rows)


if __name__ == "__main__":
    main()
