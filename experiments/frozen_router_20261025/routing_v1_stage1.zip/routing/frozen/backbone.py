"""Frozen segmentation forward with F2/F3/F4/C from one B0 pass."""
import hashlib
from pathlib import Path

import torch
from torch import nn
from torch.nn import functional as F
from transformers import SegformerForSemanticSegmentation

from core.models import CHECKPOINTS


def checkpoint_revision(net, checkpoint):
    path = Path(checkpoint)
    if path.is_dir():
        files = sorted([*path.glob("*.safetensors"), *path.glob("pytorch_model*.bin"), path / "config.json"])
        digest = hashlib.sha256()
        if not any(f.suffix in (".safetensors", ".bin") for f in files):
            raise ValueError("Local checkpoint has no safetensors/PyTorch weight files")
        for file in files:
            digest.update(file.name.encode())
            with file.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
        return "sha256:" + digest.hexdigest()
    revision = getattr(net.config, "_commit_hash", None)
    if not revision:
        raise ValueError("Cannot identify checkpoint revision; use a complete local checkpoint directory")
    return revision


class FrozenB0(nn.Module):
    def __init__(self, checkpoint=CHECKPOINTS["b0"], local_only=False):
        super().__init__()
        self.net = SegformerForSemanticSegmentation.from_pretrained(checkpoint, local_files_only=local_only)
        self.net.requires_grad_(False).eval()
        self._revision = checkpoint_revision(self.net, checkpoint)
        self.register_buffer("mean", torch.tensor([.485, .456, .406])[None, :, None, None] * 255)
        self.register_buffer("std", torch.tensor([.229, .224, .225])[None, :, None, None] * 255)
        self._c = None
        self.net.decode_head.classifier.register_forward_pre_hook(self._capture)
        self.eval()

    def _capture(self, module, args):
        self._c = args[0]

    def train(self, mode=True):
        # Calling selector.train() must never turn dropout/BN on in the segmentator.
        return super().train(False)

    @torch.no_grad()
    def forward(self, image, size, layers=()):
        result = self.net(pixel_values=(image.float() - self.mean) / self.std,
                          output_hidden_states=bool(set(layers) & {"F2", "F3", "F4"}))
        logits = F.interpolate(result.logits.float(), (size[1], size[0]), mode="bilinear", align_corners=False)
        p = logits.softmax(1)
        top = p.topk(2, dim=1).values
        entropy = -(p * p.clamp_min(1e-12).log()).sum(1)
        conf_full = torch.stack([entropy, 1 - top[:, 0], 1 - (top[:, 0] - top[:, 1])], 1)
        conf = F.interpolate(conf_full, result.logits.shape[-2:], mode="area")
        maps = {}
        for name in layers:
            maps[name] = self._c.detach() if name == "C" else result.hidden_states[int(name[1:]) - 1].detach()
        self._c = None
        return {"pred": p.argmax(1), "entropy": entropy, "confidence": conf, "maps": maps,
                "confidence_full": conf_full}

    @property
    def revision(self):
        return self._revision


def load_b2(checkpoint=CHECKPOINTS["b2"], local_only=False, device="cuda"):
    net = SegformerForSemanticSegmentation.from_pretrained(checkpoint, local_files_only=local_only)
    net._frozen_revision = checkpoint_revision(net, checkpoint)
    return net.to(device).eval().requires_grad_(False)


@torch.no_grad()
def b2_predict(net, image, size):
    mean = image.new_tensor([.485, .456, .406], dtype=torch.float32)[None, :, None, None] * 255
    std = image.new_tensor([.229, .224, .225], dtype=torch.float32)[None, :, None, None] * 255
    logits = net(pixel_values=(image.float() - mean) / std).logits
    return F.interpolate(logits.float(), (size[1], size[0]), mode="bilinear", align_corners=False).argmax(1)


@torch.no_grad()
def b2_windows(net, source, size, selected, tile, margin, max_batch, precision="fp32"):
    from routing.frozen.common import boxes, window_origin
    grid = boxes(size, tile)
    sx, sy = source.shape[-1] / size[0], source.shape[-2] / size[1]
    if abs(sx - sy) > 1e-4:
        raise ValueError("B2 window mapping expects preserved aspect ratio")
    edge = tile + 2 * margin
    out = torch.zeros((size[1], size[0]), dtype=torch.uint8, device=source.device)
    for start in range(0, len(selected), max_batch):
        batch_ids = selected[start:start + max_batch]
        crops, origins = [], []
        for k in batch_ids:
            wx, wy = window_origin(grid[k], size, tile, margin)
            x0, y0 = round(wx * sx), round(wy * sy)
            x1, y1 = round((wx + edge) * sx), round((wy + edge) * sy)
            crops.append(source[:, y0:y1, x0:x1])
            origins.append((wx, wy))
        # Rounding may differ by one pixel; resize explicitly to a common source-grid size.
        target = (round(edge * sy), round(edge * sx))
        crops = [F.interpolate(c[None].float(), target, mode="bilinear", align_corners=False)[0]
                 if c.shape[-2:] != target else c for c in crops]
        with torch.autocast(source.device.type, dtype=torch.float16, enabled=precision == "fp16"):
            pred = b2_predict(net, torch.stack(crops), (edge, edge))
        for p, k, (wx, wy) in zip(pred, batch_ids, origins):
            x0, y0, x1, y1 = grid[k]
            out[y0:y1, x0:x1] = p[y0 - wy:y1 - wy, x0 - wx:x1 - wx]
    return out
