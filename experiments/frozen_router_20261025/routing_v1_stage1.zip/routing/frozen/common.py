"""CPU helpers shared by export, training and evaluation."""
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy import ndimage


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def cache_path(root, image_id):
    return Path(root) / (hashlib.sha256(image_id.encode()).hexdigest()[:24] + ".npz")


def manifest(root):
    m = read_json(Path(root) / "manifest.json")
    if m.get("schema") != 1 or not m.get("complete") or not m["images"]:
        raise ValueError("Empty or incompatible frozen-routing cache")
    return m


def compatible(a, b):
    keys = ("b0", "b2", "b0_revision", "b2_revision", "size", "tile", "margin", "b2_input", "layers", "precision")
    for key in keys:
        if a[key] != b[key]:
            raise ValueError(f"Incompatible caches: {key}: {a[key]!r} != {b[key]!r}")


def assert_disjoint(a, b):
    compatible(a, b)
    if a["dataset"] == b["dataset"] and set(a["images"]) & set(b["images"]):
        raise ValueError("Training and validation images overlap")


def components(pred):
    out = np.full(pred.shape, -1, np.int32)
    classes = []
    for c in np.unique(pred):
        labels, n = ndimage.label(pred == c, structure=np.ones((3, 3), bool))
        inside = labels > 0
        out[inside] = labels[inside] - 1 + len(classes)
        classes.extend([int(c)] * n)
    return out, np.asarray(classes)


def boxes(size, tile):
    w, h = size
    return [(x, y, min(x + tile, w), min(y + tile, h))
            for y in range(0, h, tile) for x in range(0, w, tile)]


def window_origin(box, size, tile, margin):
    w, h = size
    edge = tile + 2 * margin
    if edge > min(w, h):
        raise ValueError("Window with context exceeds working image dimensions")
    return min(max(box[0] - margin, 0), w - edge), min(max(box[1] - margin, 0), h - edge)


def confusion(gt, pred, classes=19):
    valid = gt != 255
    return np.bincount(gt[valid].astype(np.int64) * classes + pred[valid].astype(np.int64),
                       minlength=classes ** 2).reshape(classes, classes)


def miou(conf):
    tp = np.diag(conf)
    union = conf.sum(0) + conf.sum(1) - tp
    return float(100 * np.mean(tp[union > 0] / union[union > 0]))


def tile_means(score_map, size, tile):
    return np.asarray([score_map[y0:y1, x0:x1].mean() for x0, y0, x1, y1 in boxes(size, tile)])


def merge_tiles(b0, b2, scores, threshold, size, tile):
    out = b0.copy()
    chosen = np.flatnonzero(scores > threshold)
    grid = boxes(size, tile)
    for k in chosen:
        x0, y0, x1, y1 = grid[k]
        out[y0:y1, x0:x1] = b2[y0:y1, x0:x1]
    return out, len(chosen)


def ridge_fit(x, y, weights, alpha=1.0):
    """Weighted standardized ridge; intercept is not regularized."""
    if len(x) == 0 or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Empty/nonfinite training table")
    if alpha <= 0 or np.any(weights < 0) or weights.sum() <= 0:
        raise ValueError("Positive alpha and nonnegative nonzero weights required")
    weights = weights / weights.mean()
    mean = np.average(x, axis=0, weights=weights)
    scale = np.sqrt(np.average((x - mean) ** 2, axis=0, weights=weights)).clip(1e-6)
    a = np.column_stack([(x - mean) / scale, np.ones(len(x))])
    root = np.sqrt(weights)
    penalty = np.eye(a.shape[1]) * alpha * len(x)
    penalty[-1, -1] = 0
    coef = np.linalg.solve((a * root[:, None]).T @ (a * root[:, None]) + penalty,
                           (a * root[:, None]).T @ (y * root))
    return {"mean": mean, "scale": scale, "coef": coef}


def ridge_predict(model, x):
    return np.column_stack([(x - model["mean"]) / model["scale"], np.ones(len(x))]) @ model["coef"]
