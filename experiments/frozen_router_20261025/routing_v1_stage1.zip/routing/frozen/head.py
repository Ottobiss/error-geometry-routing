"""Only this small spatial selector is trainable. All inputs are detached B0 maps."""
import torch
from torch import nn
from torch.nn import functional as F

CHANNELS = {"F2": 64, "F3": 160, "F4": 256, "C": 256}


class SpatialSelector(nn.Module):
    def __init__(self, layers=(), width=16, confidence="entropy"):
        super().__init__()
        self.layers, self.confidence = tuple(layers), confidence
        self.conf_channels = 1 if confidence == "entropy" else 3
        self.project = nn.ModuleDict({k: nn.Sequential(nn.Conv2d(CHANNELS[k], width, 1),
                                                      nn.GroupNorm(1, width), nn.GELU()) for k in layers})
        channels = self.conf_channels + width * len(layers)
        self.mix = nn.Sequential(nn.Conv2d(channels, width, 1), nn.GELU(),
                                 nn.Conv2d(width, width, 3, padding=1, groups=width), nn.GELU(),
                                 nn.Conv2d(width, 1, 1))

    def forward(self, confidence, maps):
        size = confidence.shape[-2:]
        inputs = [confidence[:, :self.conf_channels].detach()]
        inputs += [F.interpolate(self.project[k](maps[k].detach()), size, mode="bilinear", align_corners=False)
                   for k in self.layers]
        return self.mix(torch.cat(inputs, 1))[:, 0]


def target_at_grid(gain, valid, size):
    weight = F.adaptive_avg_pool2d(valid[:, None].float(), size)[:, 0]
    total = F.adaptive_avg_pool2d((gain * valid)[:, None].float(), size)[:, 0]
    return total / weight.clamp_min(1e-8), weight


def masked_mse(pred, target, weight):
    return ((pred - target).square() * weight).sum() / weight.sum().clamp_min(1)
