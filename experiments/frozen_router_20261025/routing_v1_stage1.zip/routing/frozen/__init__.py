"""Frozen B0/B2 routing experiments. No segmentation training."""
