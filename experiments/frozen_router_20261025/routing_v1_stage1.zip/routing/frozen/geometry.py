"""Fit train-only standardized prototypes and shared Mahalanobis on cached native maps."""
import argparse
from pathlib import Path

import numpy as np

from routing.frozen.common import cache_path, manifest, write_json


def native_labels(gt, shape, purity=.8):
    """Majority labels for spatial cells; reject mixed/ignore cells via coverage."""
    h, w = shape
    y = np.linspace(0, gt.shape[0], h + 1).astype(int)
    x = np.linspace(0, gt.shape[1], w + 1).astype(int)
    counts = []
    for c in range(19):
        integral = np.pad((gt == c).cumsum(0).cumsum(1), ((1, 0), (1, 0)))
        counts.append(integral[y[1:, None], x[None, 1:]] - integral[y[:-1, None], x[None, 1:]]
                      - integral[y[1:, None], x[None, :-1]] + integral[y[:-1, None], x[None, :-1]])
    count = np.stack(counts)
    cls = count.argmax(0)
    area = np.diff(y)[:, None] * np.diff(x)[None]
    return np.where(count.max(0) >= purity * area, cls, 255)


def fit_geometry(x, labels, eta=1e-3):
    if eta <= 0 or not np.isfinite(x).all():
        raise ValueError("Positive eta and finite features required")
    mean = x.mean(0)
    scale = x.std(0).clip(1e-6)
    z = (x - mean) / scale
    present = np.bincount(labels, minlength=19) > 0
    centers = np.zeros((19, x.shape[1]))
    for c in np.flatnonzero(present):
        centers[c] = z[labels == c].mean(0)
    residual = z - centers[labels]
    cov = residual.T @ residual / len(residual) + eta * np.eye(x.shape[1])
    chol = np.linalg.cholesky(cov)
    return {"mean": mean, "scale": scale, "centers": centers,
            "present": present, "whitening": np.linalg.solve(chol, np.eye(x.shape[1])).T}


def distances(x, state, metric):
    z = (x - state["mean"]) / state["scale"]
    centers = state["centers"]
    if metric == "mahalanobis":
        z = z @ state["whitening"]
        centers = centers @ state["whitening"]
    elif metric != "euclidean":
        raise ValueError(metric)
    d = np.maximum(0, (z * z).sum(1)[:, None] + (centers * centers).sum(1)[None] - 2 * z @ centers.T)
    d[:, ~state["present"]] = np.inf
    return np.sqrt(d) if metric == "euclidean" else d


def load_states(path):
    with np.load(path) as z:
        names = sorted({k.split("__")[0] for k in z.files})
        return {name: {k.split("__", 1)[1]: z[k] for k in z.files if k.startswith(name + "__")} for name in names}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ref", type=Path, required=True)
    ap.add_argument("--layers", default="F2,F3,F4,C")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--max-samples", type=int, default=20000)
    ap.add_argument("--per-image", type=int, default=512)
    ap.add_argument("--purity", type=float, default=.8)
    ap.add_argument("--eta", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    meta = manifest(args.ref)
    if args.out.exists() or args.max_samples < 2 or args.per_image < 1 or not 0 < args.purity <= 1:
        raise ValueError("Fresh output and valid sampling parameters required")
    args.out.mkdir(parents=True)
    rng = np.random.default_rng(args.seed)
    states = {}
    for layer in args.layers.split(","):
        if layer not in meta["layers"]:
            raise ValueError(f"Unavailable layer {layer}")
        # Reservoir priorities make memory bounded without privileging early images.
        bank, labels, priorities = None, None, None
        for image_id in meta["images"]:
            with np.load(cache_path(args.ref, image_id)) as r:
                f = r[layer].astype(np.float32)
                target = native_labels(r["gt"], f.shape[-2:], args.purity).ravel()
            idx = np.flatnonzero(target != 255)
            idx = rng.choice(idx, min(len(idx), args.per_image), replace=False)
            if not len(idx):
                continue
            x = f.reshape(f.shape[0], -1).T[idx]
            y, p = target[idx], rng.random(len(idx))
            bank = x if bank is None else np.concatenate([bank, x])
            labels = y if labels is None else np.concatenate([labels, y])
            priorities = p if priorities is None else np.concatenate([priorities, p])
            if len(bank) > args.max_samples:
                keep = np.argpartition(priorities, args.max_samples - 1)[:args.max_samples]
                bank, labels, priorities = bank[keep], labels[keep], priorities[keep]
        if bank is None or len(bank) < 2:
            raise ValueError("Not enough pure labelled cells")
        state = fit_geometry(bank.astype(np.float64), labels, args.eta)
        states.update({layer + "__" + k: v for k, v in state.items()})
    np.savez(args.out / "statistics.npz", **states)
    write_json(args.out / "config.json", {"ref_manifest": meta, "eta": args.eta, "purity": args.purity,
                                         "max_samples": args.max_samples, "per_image": args.per_image,
                                         "seed": args.seed, "layers": args.layers.split(","),
                                         "sampling": "uniform per-image cap then global reservoir; missing classes flagged"})


if __name__ == "__main__":
    main()
