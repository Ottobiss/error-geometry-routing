"""Identical selector input conversion for cached evaluation and live routing."""
from pathlib import Path

import numpy as np

from routing.frozen.common import read_json, ridge_predict
from routing.frozen.regional import features


class Predictor:
    def __init__(self, run=None, device="cpu", mode="learned"):
        self.device, self.mode = device, mode
        self.config = None
        if mode == "entropy":
            self.layers = []
            return
        self.config = read_json(Path(run) / "config.json")
        self.layers = self.config["layers"]
        self.geometry = None
        if self.config.get("geometry"):
            from routing.frozen.geometry import load_states
            self.geometry = load_states(Path(run) / "geometry.npz")
        if self.config["kind"] == "ridge":
            with np.load(Path(run) / "selector.npz") as z:
                self.model = {k: z[k] for k in z.files}
        else:
            import torch
            from routing.frozen.head import SpatialSelector
            self.model = SpatialSelector(self.layers, self.config["width"], self.config["confidence"]).to(device)
            checkpoint = torch.load(Path(run) / "selector.pt", map_location=device, weights_only=True)
            if checkpoint["config"]["layers"] != self.layers:
                raise ValueError("Checkpoint/config mismatch")
            self.model.load_state_dict(checkpoint["state_dict"])
            self.model.eval()

    def score(self, record):
        if self.mode == "entropy":
            return record["entropy"]
        if self.config["kind"] == "ridge":
            x, comp, _ = features(record, self.layers, self.config["confidence"], self.geometry, self.config.get("metric", "euclidean"))
            return ridge_predict(self.model, x)[comp]
        import torch
        from torch.nn import functional as F
        with torch.no_grad():
            conf = torch.as_tensor(record["confidence"].astype(np.float32), device=self.device)[None]
            maps = {k: torch.as_tensor(record[k].astype(np.float32), device=self.device)[None] for k in self.layers}
            score = self.model(conf, maps)
            return F.interpolate(score[:, None], record["b0"].shape, mode="bilinear",
                                 align_corners=False)[0, 0].cpu().numpy()
