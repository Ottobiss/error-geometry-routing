"""CPU component features and a reproducible ridge selector; no segmentation imports."""
import numpy as np
from scipy import ndimage

from routing.frozen.common import components, ridge_predict


def resize_map(x, shape):
    return ndimage.zoom(x, (shape[0] / x.shape[0], shape[1] / x.shape[1]), order=1, prefilter=False)


def features(record, layers=(), confidence="entropy", geometry=None, metric="euclidean"):
    pred = record["b0"]
    comp, cls = components(pred)
    n = len(cls)
    area = np.bincount(comp.ravel(), minlength=n).astype(float)
    cols = [area / pred.size]
    for c in range(19):
        cols.append((cls == c).astype(float))
    maps = [record["entropy"]]
    if confidence == "all":
        maps += [resize_map(x, pred.shape) for x in record["confidence"][1:]]
    elif confidence != "entropy":
        raise ValueError("Unknown confidence group")
    for m in maps:
        mean = np.bincount(comp.ravel(), weights=m.ravel(), minlength=n) / area
        std = np.sqrt(np.maximum(0, np.bincount(comp.ravel(), weights=m.ravel() ** 2, minlength=n) / area - mean ** 2))
        cols.extend([mean, std])
    slices = ndimage.find_objects(comp + 1)
    cols.extend([np.asarray([s[1].stop - s[1].start for s in slices]) / pred.shape[1],
                 np.asarray([s[0].stop - s[0].start for s in slices]) / pred.shape[0]])
    # Process one channel at a time instead of allocating (channels, H, W).
    for layer in layers:
        if geometry is not None:
            from routing.frozen.geometry import distances
            state = geometry[layer]
            f = record[layer].astype(np.float64)
            d = distances(f.reshape(f.shape[0], -1).T, state, metric)
            near = d.min(1).reshape(f.shape[-2:])
            near_full = resize_map(near, pred.shape)
            own = np.empty(pred.shape, np.float64)
            other = np.empty(pred.shape, np.float64)
            for c in np.unique(cls):
                mask = cls[comp] == c
                own[mask] = resize_map(d[:, c].reshape(f.shape[-2:]), pred.shape)[mask] if state["present"][c] else near_full[mask]
                alternatives = d.copy()
                alternatives[:, c] = np.inf
                if not np.isfinite(alternatives.min(1)).all():
                    other[mask] = near_full[mask]
                else:
                    other[mask] = resize_map(alternatives.min(1).reshape(f.shape[-2:]), pred.shape)[mask]
            for m in (own, near_full, own - other):
                cols.extend([np.bincount(comp.ravel(), weights=m.ravel(), minlength=n) / area,
                             np.asarray([np.quantile(m[comp == k], .9) for k in range(n)])])
            cols.append((~state["present"][cls]).astype(float))
            continue
        for channel in record[layer]:
            m = resize_map(channel.astype(np.float32), pred.shape)
            mean = np.bincount(comp.ravel(), weights=m.ravel(), minlength=n) / area
            std = np.sqrt(np.maximum(0, np.bincount(comp.ravel(), weights=m.ravel() ** 2, minlength=n) / area - mean ** 2))
            cols.extend([mean, std])
    return np.stack(cols, 1), comp, area


def targets(record, comp):
    n = int(comp.max()) + 1
    valid = record["valid"]
    count = np.bincount(comp[valid], minlength=n)
    gain = np.bincount(comp.ravel(), weights=record["gain"].ravel(), minlength=n)
    return gain / np.maximum(count, 1), count


def score_map(record, model, layers, confidence):
    x, comp, _ = features(record, layers, confidence)
    return ridge_predict(model, x)[comp]
