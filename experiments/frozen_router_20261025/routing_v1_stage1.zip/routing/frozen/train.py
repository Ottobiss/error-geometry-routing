"""Train selector only, from frozen caches. Never constructs B0/B2 or updates them."""
import argparse
import shutil
from pathlib import Path

import numpy as np

from routing.frozen.common import assert_disjoint, cache_path, manifest, read_json, ridge_fit, ridge_predict, write_json
from routing.frozen.regional import features, targets


def load_record(root, image_id):
    with np.load(cache_path(root, image_id)) as z:
        return {k: z[k] for k in z.files}


def ridge_table(root, meta, layers, confidence, geometry=None, metric="euclidean"):
    xx, yy, ww = [], [], []
    for image_id in meta["images"]:
        record = load_record(root, image_id)
        x, comp, _ = features(record, layers, confidence, geometry, metric)
        y, weight = targets(record, comp)
        keep = weight > 0
        xx.append(x[keep]); yy.append(y[keep]); ww.append(weight[keep])
    return np.concatenate(xx), np.concatenate(yy), np.concatenate(ww)


def spatial(args, train_meta, val_meta, config):
    import torch
    from routing.frozen.head import SpatialSelector, target_at_grid, masked_mse
    torch.manual_seed(args.seed)
    if args.width < 1 or args.epochs < 1:
        raise ValueError("width/epochs must be positive")
    model = SpatialSelector(config["layers"], args.width, args.confidence).to(args.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    # Segmentation models do not exist in this process. Optimizer owns only the selector.
    assert {id(p) for g in optimizer.param_groups for p in g["params"]} == {id(p) for p in model.parameters()}
    rng = np.random.default_rng(args.seed)
    best, history = float("inf"), []

    def step(root, image_id):
        r = load_record(root, image_id)
        conf = torch.as_tensor(r["confidence"].astype(np.float32), device=args.device)[None]
        maps = {k: torch.as_tensor(r[k].astype(np.float32), device=args.device)[None] for k in config["layers"]}
        gain = torch.as_tensor(r["gain"], device=args.device)[None]
        valid = torch.as_tensor(r["valid"], device=args.device)[None]
        target, weight = target_at_grid(gain, valid, conf.shape[-2:])
        return masked_mse(model(conf, maps), target, weight)

    for epoch in range(args.epochs):
        model.train()
        losses = []
        for idx in rng.permutation(len(train_meta["images"])):
            optimizer.zero_grad(set_to_none=True)
            loss = step(args.train, train_meta["images"][idx])
            if not torch.isfinite(loss):
                raise FloatingPointError("Nonfinite selector training loss")
            loss.backward()
            optimizer.step()
            losses.append(loss.item())
        model.eval()
        with torch.no_grad():
            val = float(np.mean([step(args.val, i).item() for i in val_meta["images"]]))
        history.append({"epoch": epoch + 1, "train_mse": float(np.mean(losses)), "val_mse": val})
        print(history[-1], flush=True)
        if val < best:
            best = val
            torch.save({"state_dict": model.state_dict(), "config": config}, args.out / "selector.pt")
        write_json(args.out / "history.json", history)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--val", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--kind", choices=("ridge", "spatial"), default="ridge")
    ap.add_argument("--layers", default="", help="Empty = confidence control; e.g. F2,F3")
    ap.add_argument("--confidence", choices=("entropy", "all"), default="entropy")
    ap.add_argument("--geometry", type=Path, help="Directory produced by geometry fitting; ridge only")
    ap.add_argument("--metric", choices=("euclidean", "mahalanobis"), default="euclidean")
    ap.add_argument("--alphas", default="0.001,0.01,0.1,1")
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--width", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight-decay", type=float, default=1e-4)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    tm, vm = manifest(args.train), manifest(args.val)
    assert_disjoint(tm, vm)
    layers = args.layers.split(",") if args.layers else []
    if len(layers) != len(set(layers)) or not set(layers) <= set(tm["layers"]):
        raise ValueError("Duplicate/unavailable feature layers")
    geometry = None
    if args.geometry:
        from routing.frozen.geometry import load_states
        from routing.frozen.common import compatible
        if args.kind != "ridge" or not layers:
            raise ValueError("Geometry requires ridge and at least one layer")
        gm = read_json(args.geometry / "config.json")
        compatible(tm, gm["ref_manifest"])
        if set(gm["ref_manifest"]["images"]) & set(vm["images"]):
            raise ValueError("Geometry reference overlaps validation")
        geometry = load_states(args.geometry / "statistics.npz")
        if not set(layers) <= set(geometry):
            raise ValueError("Missing geometry statistics")
    if args.out.exists() and any(args.out.iterdir()):
        raise ValueError("Use a fresh run directory")
    args.out.mkdir(parents=True, exist_ok=True)
    config = {"schema": 1, "kind": args.kind, "layers": layers, "confidence": args.confidence,
              "width": args.width, "seed": args.seed, "train": str(args.train), "val": str(args.val),
              "train_manifest": tm, "val_manifest": vm, "epochs": args.epochs, "lr": args.lr,
              "weight_decay": args.weight_decay, "alphas": args.alphas,
              "feature_cache_dtype": "float16", "geometry": bool(args.geometry), "metric": args.metric, "target": "real_B2_tiled_gain_per_valid_pixel"}
    if args.geometry:
        shutil.copyfile(args.geometry / "statistics.npz", args.out / "geometry.npz")
        shutil.copyfile(args.geometry / "config.json", args.out / "geometry_config.json")
    write_json(args.out / "config.json", config)
    if args.kind == "spatial":
        spatial(args, tm, vm, config)
        return
    x, y, w = ridge_table(args.train, tm, layers, args.confidence, geometry, args.metric)
    vx, vy, vw = ridge_table(args.val, vm, layers, args.confidence, geometry, args.metric)
    best, history = float("inf"), []
    for alpha in map(float, args.alphas.split(",")):
        fitted = ridge_fit(x, y, w, alpha)
        mse = float(np.average((ridge_predict(fitted, vx) - vy) ** 2, weights=vw))
        history.append({"alpha": alpha, "val_mse": mse})
        if mse < best:
            best = mse
            config["selected_alpha"] = alpha
            np.savez(args.out / "selector.npz", **fitted)
    write_json(args.out / "history.json", history)
    write_json(args.out / "config.json", config)
    print(history)


if __name__ == "__main__":
    main()
