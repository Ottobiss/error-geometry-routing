"""Read-only environment check; no data/weight downloads and no cloud provisioning."""
import importlib.util
import json
import shutil
import sys


def main():
    modules = {name: bool(importlib.util.find_spec(name)) for name in
               ("torch", "transformers", "numpy", "scipy", "PIL", "cityscapesscripts")}
    report = {"python": sys.version, "modules": modules, "nvidia_smi": shutil.which("nvidia-smi")}
    if modules["torch"]:
        import torch
        report.update(torch=torch.__version__, cuda_available=torch.cuda.is_available())
        if torch.cuda.is_available():
            report["gpu"] = torch.cuda.get_device_name()
            report["total_memory_bytes"] = torch.cuda.get_device_properties(0).total_memory
    if modules["transformers"]:
        import transformers
        report["transformers"] = transformers.__version__
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not all(modules.values()) or not report.get("cuda_available"):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
