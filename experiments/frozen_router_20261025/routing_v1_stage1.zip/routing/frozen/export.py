"""Export one immutable cache for a disjoint image split, using frozen B0/B2."""
import argparse
from pathlib import Path

import numpy as np
import torch

from core.data import DATASETS, loader
from core.models import CHECKPOINTS
from routing.frozen.backbone import FrozenB0, load_b2, b2_windows
from routing.frozen.common import boxes, cache_path, write_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=DATASETS, default="cityscapes")
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--split", default="val", choices=("train", "val", "test"))
    ap.add_argument("--ids", type=Path, required=True, help="Explicit image ids; no automatic train/test reuse")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--layers", default="F2,F3,F4,C")
    ap.add_argument("--b0", default=CHECKPOINTS["b0"])
    ap.add_argument("--b2", default=CHECKPOINTS["b2"])
    ap.add_argument("--b2-input", choices=("image", "small"), default="image")
    ap.add_argument("--tile", type=int, default=256)
    ap.add_argument("--margin", type=int, default=64)
    ap.add_argument("--max-batch", type=int, default=2)
    ap.add_argument("--precision", choices=("fp32", "fp16"), default="fp32")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--limit", type=int)
    ap.add_argument("--local-only", action="store_true")
    args = ap.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise ValueError("Use a fresh output directory; never mix caches")
    if args.max_batch < 1 or args.tile < 1 or args.margin < 0:
        raise ValueError("Invalid window parameters")
    ids = args.ids.read_text().split()
    if len(ids) != len(set(ids)) or not ids:
        raise ValueError("Image ids must be nonempty and unique")
    layers = args.layers.split(",") if args.layers else []
    if not set(layers) <= {"F2", "F3", "F4", "C"}:
        raise ValueError("Unknown feature layer")
    cls = DATASETS[args.dataset]
    cls.root = args.root
    ds = cls(ids=ids, full=args.b2_input == "image", split=args.split)
    if set(ds.image_ids) != set(ids):
        raise ValueError("Some requested ids were not found in the supplied dataset/split")
    if args.limit:
        ds.items = ds.items[:args.limit]
        ds.image_ids = ds.image_ids[:args.limit]
    b0 = FrozenB0(args.b0, args.local_only).to(args.device)
    b2 = load_b2(args.b2, args.local_only, args.device)
    args.out.mkdir(parents=True, exist_ok=True)
    meta = {"schema": 1, "dataset": args.dataset, "split": args.split, "images": ds.image_ids,
            "size": list(ds.size), "layers": layers, "b0": args.b0, "b2": args.b2,
            "b0_revision": b0.revision, "b2_revision": b2._frozen_revision,
            "tile": args.tile, "margin": args.margin, "b2_input": args.b2_input,
            "max_batch": args.max_batch, "precision": args.precision, "complete": False}
    write_json(args.out / "manifest.json", meta)
    with torch.no_grad():
        for i, sample in enumerate(loader(ds, args.workers)):
            result = b0(sample["small"][None].to(args.device), ds.size, layers)
            pred = result["pred"][0].cpu().numpy().astype(np.uint8)
            tiled = b2_windows(b2, sample[args.b2_input].to(args.device), ds.size,
                               list(range(len(boxes(ds.size, args.tile)))), args.tile, args.margin,
                               args.max_batch, args.precision).cpu().numpy()
            gt = sample["label"].numpy().astype(np.uint8)
            valid = gt != 255
            gain = ((tiled == gt).astype(np.int8) - (pred == gt).astype(np.int8)) * valid
            payload = {"b0": pred, "b2": tiled, "gt": gt, "valid": valid, "gain": gain,
                       "entropy": result["entropy"][0].cpu().numpy().astype(np.float32),
                       "confidence": result["confidence"][0].cpu().numpy().astype(np.float16)}
            payload.update({k: v[0].cpu().numpy().astype(np.float16) for k, v in result["maps"].items()})
            np.savez_compressed(cache_path(args.out, sample["image_id"]), **payload)
            print(f"{i + 1}/{len(ds)} {sample['image_id']}", flush=True)
    meta["complete"] = True
    write_json(args.out / "manifest.json", meta)


if __name__ == "__main__":
    main()
