# Замороженные B0/B2: F2/F3 и обучение только селектора

Рабочая ветка: `frozen-router-f2-f3`, база `geometry` на `0c91136f9e6ef0fadf82330c94560100c0645db4`.
Существующие ветки не изменяются. Новая реализация находится в `routing/frozen/` и не переписывает прежние эксперименты.

## Что реализовано

- Один замороженный B0: F2/F3/F4 и вход финального classifier C (256 каналов обычного B0).
- B2 заморожена, получает реальные окна с контекстом. Цели построены по этим окнам, а не по полному B2.
- Восьмисвязные компоненты; их агрегаты и scores переводятся в окна по пространственному перекрытию.
- Ridge по компонентам: уверенность/форма/класс; добавление средних и разброса F2/F3; опционально евклидова геометрия или shared Mahalanobis.
- Маленькая spatial-head: проекции 1×1, depthwise 3×3, линейный выход. Сегментаторы не создаются в процессе обучения головы: используются только кэши.
- Пороги на validation; сквозной замер от кадра на GPU до маски на CPU, включая геометрию, CPU-компоненты, передачи данных, селектор и B2.
- Кэши и веса проверяются на совпадение checkpoint/revision, политики кропов, precision, наличия слоёв и пересечения train/validation. Незавершённые кэши не используются.

Это первая реализация для запуска экспериментов, не подтверждённый выигрыш. kNN, инъекция токенов, отдельный кадровый гейт и строгий планировщик миллисекундного бюджета пока не добавлены. Вместо λ используется эквивалентный для фиксированных окон порог score; фактическая стоимость зависит от числа окон и batching, поэтому рабочая точка выбирается по LIVE-замерам validation.

## 1. Окружение и данные

Все команды из корня новой ветки. Используйте отдельное окружение на VM с уже рабочим CUDA PyTorch и Hugging Face SegFormer. Не переустанавливайте рабочую CUDA-среду по старому requirements.txt без проверки его версий. Новых зависимостей сверх NumPy/SciPy/PyTorch/Transformers/Pillow/cityscapesscripts код не требует.

```bash
python -m routing.frozen.preflight
python -m unittest discover -s tests -p test_frozen_router.py -v
```

В среде реализации не было PyTorch/Transformers/GPU: CPU-проверки выполнены; PyTorch-тест отмечен skipped. Первый запуск на VM должен включать этот тест и маленький экспорт. Не объявляйте GPU-часть проверенной до этого.

Cityscapes должен быть распакован в стандартной структуре leftImg8bit и gtFine. Существующие P0/P1 нужны для исторического сравнения, но P1 многократно использовалась в исследовании. Для подтверждающего результата подготовьте новые непересекающиеся списки на подходящих данных, не использованных при обучении сегментаторов. Если новых данных нет, результат на прежнем P1 подписывайте exploratory.

Предварительно создайте три текстовых файла: `splits/router_train.txt`, `splits/router_val.txt`, `splits/router_test.txt`, один image_id на строку. Разделяйте также связанные последовательности. Выбор split, источника данных и количества кадров задаётся пользователем: код не делит коррелированные изображения автоматически и не скачивает датасет.

## 2. Короткий GPU smoke-test

```bash
python -m routing.frozen.export \
  --dataset cityscapes --root /data/cityscapes --split val \
  --ids splits/router_train.txt --out results/frozen/smoke \
  --layers F2,F3,F4,C --limit 2 --max-batch 1
```

`--limit` сохраняет отдельный неполный по числу кадров, но завершённый кэш для smoke-test. Не используйте его как полноценную обучающую выборку. Проверить совпадение размеров, масок, gain и отсутствие NaN/Inf. Для локальных checkpoint доступны `--b0 /models/b0 --b2 /models/b2 --local-only`; каталог должен содержать config и веса. Для Hub по умолчанию используются те же NVIDIA checkpoint, что и в geometry. Фиксируются resolved revision; локальные веса хэшируются.

## 3. Экспорт train/validation/test — один раз

```bash
for part in train val test; do
  python -m routing.frozen.export \
    --dataset cityscapes --root /data/cityscapes --split val \
    --ids "splits/router_${part}.txt" --out "results/frozen/${part}" \
    --layers F2,F3,F4,C --b2-input image --precision fp32 --max-batch 2
done
```

Здесь `--split val` — исходный split Cityscapes, а train/val/test в именах каталогов — роли для селектора. Для другого исходного split поменять аргумент согласованно. Размер окна 256 + контекст 64 задан в рабочей сетке 1024×512; при полном исходном кадре окно B2 получается 768×768. Это не окно 384×384 на исходной фотографии.

Для ACDC нужен отдельный кэш и явно выбранный B2-input small/image; прежняя подстройка разрешения по ACDC val остаётся ограничением исторического протокола. Новая программа не выбирает разрешение автоматически по тестовой разметке.

Кэш занимает место: F2/F3/F4/C в float16, маски/цели, confidence и энтропия. Сначала измерьте объём smoke-кэша и умножьте на число кадров. Полные признаки на диск не увеличиваются до разрешения кадра. CPU-компонентный селектор интерполирует по одному каналу при применении; это может быть медленно и намеренно включается в LIVE-время.

Не меняйте веса, dtype B2, tile/margin или предобработку после экспорта. Для fp16 создайте отдельные кэши с `--precision fp16`; не обучайте/не тестируйте на ответах другой precision без проверки. B0 во всех режимах FP32.

## 4. Основные контроли и признаки F2/F3

```bash
python -m routing.frozen.train --train results/frozen/train --val results/frozen/val \
  --out results/frozen/ridge_entropy --kind ridge

python -m routing.frozen.train --train results/frozen/train --val results/frozen/val \
  --out results/frozen/ridge_confidence --kind ridge --confidence all

python -m routing.frozen.train --train results/frozen/train --val results/frozen/val \
  --out results/frozen/ridge_f2 --kind ridge --layers F2

python -m routing.frozen.train --train results/frozen/train --val results/frozen/val \
  --out results/frozen/ridge_f3 --kind ridge --layers F3

python -m routing.frozen.train --train results/frozen/train --val results/frozen/val \
  --out results/frozen/ridge_f2_f3 --kind ridge --layers F2,F3
```

Контроль ridge_entropy содержит класс и форму плюс среднюю/разброс энтропии, а не только один столбец. Все обучаемые ridge сравнения имеют те же класс и форму. Прямой необучаемый baseline — средняя энтропия окна (`--mode entropy`).

Ridge обучается на Δ/n_valid с весом n_valid. При этом выбранное действие — окно, не произвольный bbox компоненты. Цель компоненты собрана по мозаике B2-окон; при переводе её score на окно предполагается пространственное усреднение. Это приближение, проверяемое по реальному итоговому mIoU. Пространственная голова напрямую получает подписанную карту исправлений той же мозаики.

## 5. Евклидова геометрия и Махаланобис

```bash
python -m routing.frozen.geometry --ref results/frozen/train \
  --layers F2,F3,F4,C --out results/frozen/reference --max-samples 20000

for layer in F2 F3 F4 C; do
  for metric in euclidean mahalanobis; do
    python -m routing.frozen.train --train results/frozen/train --val results/frozen/val \
      --kind ridge --layers "$layer" --geometry results/frozen/reference --metric "$metric" \
      --out "results/frozen/${metric}_${layer}"
  done
done
```

Статистики подгоняются только по train/reference. Контроль чистоты GT-ячеек 0.8, максимум опор и регуляризация ковариации сохраняются в config. Выборка ограничена на кадр, затем глобально; она не сбалансирована по классам. Отсутствующие классы отмечаются отдельным признаком; их own-distance заменяется nearest-distance. Перед выводами проверить покрытие классов.

Геометрия: own, near, gap; среднее и q90 по компоненте, плюс флаг отсутствующего класса. Стандартизация опор и shared covariance отдельные для слоя. Ковариация регуляризована, факторизация выполняется один раз. Это post-hoc-адаптация, не полноценное воспроизведение DDU. Значение eta по умолчанию не следует считать оптимальным; настраивать только внутри разработки.

## 6. Обучение маленькой головы — только селектор

```bash
python -m routing.frozen.train --train results/frozen/train --val results/frozen/val \
  --out results/frozen/head_entropy --kind spatial --epochs 20 --device cuda

python -m routing.frozen.train --train results/frozen/train --val results/frozen/val \
  --out results/frozen/head_f2_f3 --kind spatial --layers F2,F3 --epochs 20 --device cuda
```

Процесс обучения не загружает сегментаторы вообще. B0/B2-веса не входят в checkpoint селектора. Оптимизатор содержит только параметры spatial-head. Числовые входы кастуются из того же float16-кэша, который воспроизводится при LIVE-применении. Проекции каналов и GroupNorm находятся внутри головы. Цель — усреднённая по ячейке signed gain, loss взвешен долей валидных пикселей; это приближение полной попиксельной цели, а не точный loss mIoU.

Выбор alpha/эпохи производится по validation MSE, не по test. Затем независимо на validation выбирается threshold по качеству/времени. Уверенность B2 не является основной целью. Геометрические агрегаты и spatial-head — две отдельные группы экспериментов.

## 7. Порог на validation и реальный замер

```bash
python -m routing.frozen.calibrate --cache results/frozen/val \
  --run results/frozen/head_f2_f3 --device cuda --out results/frozen/head_f2_f3/thresholds.json

python -m routing.frozen.live --dataset cityscapes --root /data/cityscapes --split val \
  --ids splits/router_val.txt --run results/frozen/head_f2_f3 \
  --calibration results/frozen/head_f2_f3/thresholds.json --validation-sweep \
  --precision fp32 --out results/frozen/head_f2_f3/live_val.json
```

Повторить для финалистов. Для энтропии:

```bash
python -m routing.frozen.calibrate --cache results/frozen/val --mode entropy \
  --out results/frozen/entropy_thresholds.json
python -m routing.frozen.live --dataset cityscapes --root /data/cityscapes \
  --ids splits/router_val.txt --mode entropy --calibration results/frozen/entropy_thresholds.json \
  --validation-sweep --out results/frozen/entropy_live_val.json
```

Из LIVE validation выбрать лучший mIoU при одном полном бюджете времени. Среднее число окон и cached_miou не заменяют этот замер. Скрипт не делает вид, что известен лучший бюджет без вашего требования; граница бюджета выбирается пользователем и фиксируется до test.

LIVE включает CPU-агрегацию и, для spatial-head, консервативный перенос карт GPU→CPU→GPU для точного совпадения с кэшем. Это корректная, но не оптимизированная первая версия; по её времени нельзя делать вывод о пределе скорости GPU-only головы. Если переносы доминируют, оптимизацию делать отдельно с проверкой эквивалентности scores и решений.

Полный B2 и B0 измеряются тем же инструментом:

```bash
python -m routing.frozen.live --dataset cityscapes --root /data/cityscapes \
  --ids splits/router_val.txt --mode b0 --out results/frozen/b0_live_val.json
python -m routing.frozen.live --dataset cityscapes --root /data/cityscapes \
  --ids splits/router_val.txt --mode b2 --out results/frozen/b2_live_val.json
```

Warmup выполняется на каждом кадре до таймеров, затем повторы; p95 считается по среднему повторов каждого кадра и так подписывается в отчёте. Диск, загрузка весов и первичная доставка кадра на GPU исключены одинаково. Записываются GPU, torch, версии весов, все времена повторов и confusion matrix каждого кадра.

## 8. Только фиксированная точка на test

В следующей команде 0.012 — исключительно placeholder: заменить значением, выбранным по LIVE validation.

```bash
python -m routing.frozen.live --dataset cityscapes --root /data/cityscapes \
  --ids splits/router_test.txt --run results/frozen/head_f2_f3 \
  --threshold 0.012 --out results/frozen/head_f2_f3/live_test.json
```

Не перебирать thresholds на test. Сетка calibration разрешена только на исходных validation ids. Код проверяет пересечение обучения с оценкой, но отсутствие коррелированных сцен в разных списках требует ручной проверки.

ACDC: те же веса и threshold, `--allow-domain-shift`, явно согласованный `--b2-input small`; не подбирать threshold по ACDC test. Изменение разрешения B2 относительно обучения меняет действие и остаётся отдельным domain-shift протоколом.

## Что считать успехом

1. F2/F3 добавляют mIoU относительно такого же селектора на уверенности при сопоставимом полном времени.
2. Результат сохраняется на отложенных изображениях и нескольких seed.
3. Преимущество не исчезает при сравнении с B2 целиком в том же dtype.

До GPU-проверки не сообщаем mIoU, ускорение, объём GPU-памяти или завершённое обучение. В журнал записывать checkpoint, ids, config и измеренные результаты, а не ожидаемые значения.
